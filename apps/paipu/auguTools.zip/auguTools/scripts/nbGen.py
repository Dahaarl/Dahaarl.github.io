import maya.mel as mel
import maya.cmds as cmds
import maya.app.type.AEtypeTemplate;




# Create window
if cmds.window('nbWindow', exists = True):
    cmds.deleteUI('nbWindow')
cmds.window('nbWindow', title = "Create Numbers", width = 250, height = 400)

cmds.showWindow('nbWindow')




def createMarkers(*args):
    print("create markers")
    if cmds.objExists('nbGen_Loc'):
        cmds.warning("Locators Already exists !")
        return
    cmds.spaceLocator(name = 'nbGen_Loc')
    cmds.spaceLocator(name = 'increment_x_Loc')
    cmds.spaceLocator(name = 'increment_y_Loc')
    cmds.spaceLocator(name = 'increment_z_Loc')
    cmds.parent( 'increment_x_Loc', 'nbGen_Loc' )
    cmds.parent( 'increment_y_Loc', 'nbGen_Loc' )
    cmds.parent( 'increment_z_Loc', 'nbGen_Loc' )
 
 
 
 
def generate(*args):
    if not cmds.objExists('nbGen_Loc'):
        cmds.warning("Can't find markers :(")
        return
    yIncrement = cmds.getAttr("increment_y_Loc.translateY")
    xIncrement = cmds.getAttr("increment_x_Loc.translateX")
    zIncrement = cmds.getAttr("increment_z_Loc.translateZ")
    
    rows = cmds.intField('rowsField', query = True, value = True )
    columns = cmds.intField('columnsField', query = True, value = True )
    
    fontSize = cmds.intField('fontSizeField', query = True, value = True )
    currentFont = cmds.optionMenu('fontList', query = True, value = True )
    current_number = cmds.intField('startField', query = True, value = True )
    
    current_yPosition = cmds.getAttr("nbGen_Loc.translateY")
    current_xPosition = cmds.getAttr("nbGen_Loc.translateX")
    current_zPosition = cmds.getAttr("nbGen_Loc.translateZ")
    
    old_yPosition = current_yPosition
    old_xPosition = current_xPosition
    old_zPosition = current_zPosition
    
     
    import maya.mel
    gMainProgressBar = maya.mel.eval('$tmp = $gMainProgressBar')
    
    cmds.progressBar( gMainProgressBar,
    				edit=True,
    				beginProgress=True,
    				isInterruptable=True,
    				status='Creating numbers ...',
    				maxValue= rows * columns )
    
    window = cmds.window(title = "Creating numbers...")
    cmds.columnLayout()
    progressControl = cmds.progressBar(maxValue=rows*columns, width=300)
    cmds.showWindow( window )
    
    cmds.group( empty = True, name = 'nbGen_Grp' )
    
    try:
        for i in range(0,columns):
            for j in range(0,rows):
                text = str(current_number).encode("hex")
                [text[i:i+2] for i in range(0, len(text), 2)]
                text = ' '.join([text[i:i+2] for i in range(0, len(text), 2)])
                
                number = mel.eval('CreatePolygonType')
                cmds.hyperShade( assign= "fontMaterial")
                t3d_trans = cmds.ls(sl = True)[0]
                t3d_node = cmds.listConnections('%s.message' %t3d_trans)[0]
                t3d_extrude = cmds.listConnections('%s.outputMesh' %t3d_node)[0]
                cmds.setAttr('%s.alignmentMode' %t3d_node, 2)
                cmds.setAttr('%s.textInput' %t3d_node, text, type = 'string')
                cmds.setAttr('%s.currentFont' %t3d_node, currentFont, type='string')
                cmds.setAttr('%s.fontSize' %t3d_node, fontSize)
                cmds.setAttr('%s.extrudeDistance' %t3d_extrude, 0.8)
                cmds.setAttr('%s.extrudeDivisions' %t3d_extrude, 1)
                cmds.setAttr('%s.translateY' %t3d_trans, current_yPosition)
                cmds.setAttr('%s.translateX' %t3d_trans, current_xPosition)
                cmds.setAttr('%s.translateZ' %t3d_trans, current_zPosition)
                current_yPosition += yIncrement
                print("number %s added" %current_number)
                current_number += 1
                cmds.progressBar(gMainProgressBar, edit=True, step=1)
                cmds.progressBar(progressControl, edit=True, step=1)
                cmds.group( t3d_trans, parent='nbGen_Grp' )
            
            current_yPosition = old_yPosition
            current_xPosition += xIncrement
            cmds.progressBar(gMainProgressBar, edit=True, step=1)
            cmds.progressBar(progressControl, edit=True, step=1)
    except KeyboardInterrupt:
        cmds.deleteUI(window, control = True)
        cmds.inViewMessage( amg='<hl>Canceling process...</hl>', pos='botCenter', fade=True )
    
    if cmds.progressBar(gMainProgressBar, edit=True, endProgress=True):
        cmds.deleteUI(window, control = True)
        cmds.inViewMessage( amg='<hl>Done !</hl>', pos='botCenter', fade=True )
   
   
   
   
           
mainLayout = cmds.rowColumnLayout( numberOfColumns = 1 )
cmds.separator(style = "none", height = 10)
cmds.rowColumnLayout( numberOfColumns = 3, columnWidth = [(1, 6), (2, 240), (3, 2)] ) # 2 columns
cmds.separator(style = "none", height = 25)
cmds.button(label = "Create Markers", annotation = "Create Markers", command = createMarkers)
cmds.separator(style = "none", height = 25)

cmds.setParent(mainLayout)
cmds.separator(style = "none", height = 10)
cmds.rowColumnLayout( numberOfColumns = 5, columnWidth = [(1, 70), (2, 20), (3, 75), (4, 15), (5, 70)] ) # 2 columns
cmds.separator()
cmds.separator(style = "none")
cmds.text(label = "Grid Settings", font = "boldLabelFont")
cmds.separator(style = "none")
cmds.separator()

cmds.setParent(mainLayout)
cmds.separator(style = "none", height = 10)
cmds.rowColumnLayout( numberOfColumns = 3, columnWidth = [(1, 115), (2, 100), (3, 10)] ) # 2 columns
cmds.text(label = "start from: ")
cmds.intField('startField', minValue = 0, value = 0 )
cmds.separator(style = "none")

cmds.setParent(mainLayout)
cmds.separator(style = "none", height = 10)
cmds.rowColumnLayout( numberOfColumns = 1, columnWidth = [(1, 225)] )
cmds.image( image= cmds.internalVar( usd = True) + "auguTools/scripts/icons/nbGen.png" )

cmds.setParent(mainLayout)
cmds.separator(style = "none", height = 20)
cmds.rowColumnLayout( numberOfColumns = 5, columnWidth = [(1, 40), (2, 68), (3, 10), (4, 50), (5, 68)] ) # 2 columns
cmds.text(label = "rows: ")
cmds.intField('rowsField', minValue = 0, value = 0 )
cmds.separator(style = "none", height = 20)
cmds.text(label = "columns: ")
cmds.intField('columnsField', minValue=0, value=0)

cmds.setParent(mainLayout)
cmds.separator(style = "none", height = 30)
cmds.rowColumnLayout( numberOfColumns = 5, columnWidth = [(1, 70), (2, 20), (3, 75), (4, 15), (5, 70)] ) # 2 columns
cmds.separator()
cmds.separator(style = "none")
cmds.text(label = "Font Settings", font = "boldLabelFont")
cmds.separator(style = "none")
cmds.separator()

cmds.setParent(mainLayout)
cmds.separator(style = "none", height = 20)
columns = cmds.rowColumnLayout( numberOfColumns = 4, columnWidth = [(1, 150), (2, 40), (3, 50)] ) # 2 columns
cmds.optionMenu('fontList' )
cmds.text(label = "size: ")
cmds.intField('fontSizeField', minValue = 0, value = 5 )

for font in cmds.fontDialog(FontList = True):
    cmds.menuItem( label= font, parent = 'fontList' )
    

cmds.setParent(mainLayout)
cmds.separator(style = "none", height = 20)

cmds.button(label = "Generate !", annotation = "Run script !", height = 40, command = generate)