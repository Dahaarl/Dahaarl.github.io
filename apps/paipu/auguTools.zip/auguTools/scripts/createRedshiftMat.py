import maya.cmds as cmds
import os
import pymel.core as pm

def popup():
    path = cmds.fileDialog2( fileMode = 1, fileFilter = "All Files (*.*)", dialogStyle = 2, caption = "Select A Substance map")[0]
    result = cmds.promptDialog(
            title='Name of the Material',
            message='Enter a material name:',
            button=['OK', 'Cancel'],
            defaultButton='OK',
            cancelButton='Cancel',
            dismissString='Cancel')
    if result == 'OK':
        text = cmds.promptDialog(query=True, text=True)
        if text != "":
            create( path, text )
        else:
            cmds.warning("No name is set ! :(")
            cmds.inViewMessage( amg="No <hl>name</hl> is set ! <hl>:(</hl>", pos='botCenter', fade=True )


def create(path, name):
    #create a shader
    cmds.inViewMessage( amg="Creating <hl>shader</hl>...", pos='botCenter', fade=True )
    folder_path = path.rpartition("/")[0]
    file_extension = path.rpartition(".")[2]
    prefix_name = path.rpartition("/")[2].rpartition("_")[0]
    shader = cmds.shadingNode("RedshiftMaterial", name = name, asShader=True)
    cmds.setAttr('%s.refl_brdf' %shader, 1)
    cmds.setAttr('%s.refl_fresnel_mode' %shader, 2)

    normal_node = cmds.shadingNode("RedshiftNormalMap", name = name + "_NormalMap", asShader=True)
    displace_node = cmds.shadingNode("RedshiftDisplacement", name = name + "_Displacement", asShader=True)


    for map in ["diffuse_color", "refl_roughness", "refl_metalness", "bump_input"]:
        cmds.colorManagementPrefs(cmEnabled = True, restoreDefaults = True)
        if not map == "bump_input":
            file_node = cmds.shadingNode("file", asTexture=True)
            InputColorRules()
            place_node = cmds.shadingNode("place2dTexture", asUtility=True) # place texture
            cmds.connectAttr('%s.outUV' %place_node, '%s.uvCoord' %file_node)
        if map == "diffuse_color":
            cmds.connectAttr('%s.outColor' %file_node, shader + "." + map)
        elif  map == "refl_roughness" or map ==  "refl_metalness":
            cmds.connectAttr('%s.outAlpha' %file_node, shader + "." + map)
        elif map == "bump_input":
            cmds.connectAttr('%s.outDisplacementVector' %normal_node, shader + "." + map)

        if map == "diffuse_color":
            cmds.setAttr('%s.fileTextureName' %file_node, folder_path + "/" + prefix_name + "_DiffuseColor." + file_extension, type='string')
            cmds.setAttr('%s.colorSpace' %file_node, 'sRGB', type='string')
        if map == "refl_roughness":
            cmds.setAttr('%s.fileTextureName' %file_node, folder_path + "/" + prefix_name + "_Roughness." + file_extension, type='string')
            cmds.setAttr('%s.colorSpace' %file_node, 'Raw', type='string')
            cmds.setAttr('%s.alphaIsLuminance' %file_node, True)
        if map == "refl_metalness":
            cmds.setAttr('%s.fileTextureName' %file_node, folder_path + "/" + prefix_name + "_Metallic." + file_extension, type='string')
            cmds.setAttr('%s.colorSpace' %file_node, 'Raw', type='string')
            cmds.setAttr('%s.alphaIsLuminance' %file_node, True)
        if map == "bump_input":
            cmds.setAttr('%s.tex0' %normal_node, folder_path + "/" + prefix_name + "_Normal." + file_extension, type='string')


    shading_group = cmds.sets(name = "%s_Set" %shader, renderable=True, noSurfaceShader=True, empty=True) # a shading group
    cmds.connectAttr('%s.outColor' %shader ,'%s.surfaceShader' %shading_group) # connect shader to sg surface shader
    cmds.connectAttr('%s.out' %displace_node ,'%s.displacementShader' %shading_group) # connect shader to sg surface shader
    cmds.inViewMessage( amg="Shader <hl>created</hl> !", pos='botCenter', fade=True )



def InputColorRules():
    colMgmtGlob = pm.PyNode( 'defaultColorMgtGlobals' )
    for f in pm.ls( type='file' ):
        colMgmtGlob.cmEnabled >> f.colorManagementEnabled
        colMgmtGlob.configFileEnabled >> f.colorManagementConfigFileEnabled
        colMgmtGlob.configFilePath >> f.colorManagementConfigFilePath
        colMgmtGlob.workingSpaceName >> f.workingSpace
        # cmds.setAttr('%s.colorSpace' %f, 'Raw', type='string')
