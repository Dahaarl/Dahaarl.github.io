import maya.cmds as cmds
from functools import partial
import os
import pymel.core as pm

dir_path = str(os.path.dirname(os.path.abspath(__file__)))

def create_ui():
    if cmds.window("shapeCreator", query = True, exists = True):
        cmds.deleteUI("shapeCreator")
    window = cmds.window("shapeCreator", title="Shape Creator", iconName='Short Name', width = 210, height = 150, maximizeButton = False, resizeToFitChildren = False, sizeable = False)
    mainColumn = cmds.columnLayout( adjustableColumn = True, width = 210 )

    cmds.separator(height= 5, style = 'none')

    cmds.gridLayout( numberOfColumns=3, cellWidthHeight=(70, 70), width = 210)
    cmds.iconTextButton(image1 = dir_path + "/icons/circle.svg", label = "circle", annotation = "Add circle shape", command = partial(addCtrl, "circle"))
    cmds.iconTextButton(image1 = dir_path + "/icons/rectangle.svg", label = "rectangle", annotation = "Add rectangle shape", command = partial(addCtrl, "rectangle"))
    cmds.iconTextButton(image1 = dir_path + "/icons/box.svg", label = "box", annotation = "Add box shape", command = partial(addCtrl, "box"))
    cmds.iconTextButton(image1 = dir_path + "/icons/ball.svg", label = "ball", annotation = "Add ball shape", command = partial(addCtrl, "ball"))
    cmds.iconTextButton(image1 = dir_path + "/icons/ballTarget.svg", label = "ballTarget", annotation = "Add ballTarget shape", command = partial(addCtrl, "ballTarget"))
    cmds.iconTextButton(image1 = dir_path + "/icons/arrow.svg", label = "arrow", annotation = "Add arrow shape", command = partial(addCtrl, "arrow"))
    cmds.iconTextButton(image1 = dir_path + "/icons/circleArrow.svg", label = "circleArrow", annotation = "Add circleArrow shape", command = partial(addCtrl, "circleArrow"))
    cmds.iconTextButton(image1 = dir_path + "/icons/eye.svg", label = "eye", annotation = "Add eye shape", command = partial(addCtrl, "eye"))
    cmds.iconTextButton(image1 = dir_path + "/icons/diamond.svg", label = "diamond", annotation = "Add diamond shape", command = partial(addCtrl, "diamond"))

    cmds.setParent(mainColumn)
    cmds.separator(height= 5, style = 'none')
    cmds.button(label = "Merge Selected Curves", height = 30, command = mergeCurves)
    cmds.separator(height= 5, style = 'none')
    cmds.colorSliderGrp("colorSlide", rgb=(0, 0, 1), width = 134, height = 30 )
    cmds.button(label = "Assign Color", height = 30, command = assignColor)
    cmds.separator(height= 5, style = 'none')

    cmds.showWindow( "shapeCreator" )


def addCtrl(shape, *args):
    # selection = cmds.ls( selection = True)
    # obj = selection[0]
    new_curve = None
    if shape == "circle":
        cmds.file( dir_path + "/shapes/circle.ma", i = True )
    if shape == "rectangle":
        cmds.file( dir_path + "/shapes/rectangle.ma", i = True )
    if shape == "box":
        cmds.file( dir_path + "/shapes/box.ma", i = True )
    if shape == "ball":
        cmds.file( dir_path + "/shapes/ball.ma", i = True )
    if shape == "ballTarget":
        cmds.file( dir_path + "/shapes/ballTarget.ma", i = True )
    if shape == "arrow":
        cmds.file( dir_path + "/shapes/arrow.ma", i = True )
    if shape == "circleArrow":
        cmds.file( dir_path + "/shapes/circleArrow.ma", i = True )
    if shape == "eye":
        cmds.file( dir_path + "/shapes/eye.ma", i = True )
    if shape == "diamond":
        cmds.file( dir_path + "/shapes/diamond.ma", i = True )
    # if obj != None:
    #     print(obj)
    #     print(new_curve)
        # cmds.parentConstraint( obj, new_curve )
        # cmds.setAttr("{0}.translateX".format(new_curve), cmds.getAttr("{0}.translateX".format(selection[0])))
        # cmds.setAttr("{0}.translateY".format(new_curve), cmds.getAttr("{0}.translateY".format(selection[0])))
        # cmds.setAttr("{0}.translateZ".format(new_curve), cmds.getAttr("{0}.translateZ".format(selection[0])))

def assignColor(*args):
    color = cmds.colorSliderGrp("colorSlide", query = True, rgbValue = True )
    print(color)
    obj = cmds.ls( selection = True)
    shapeNodes = cmds.listRelatives(obj, shapes = True)
    print(shapeNodes)
    for shape in shapeNodes:
        cmds.setAttr("{0}.overrideEnabled".format(shape), True)
        cmds.setAttr("{0}.overrideRGBColors".format(shape), True)
        cmds.setAttr("{0}.overrideColorRGB".format(shape), color[0], color[1], color[2])


def mergeCurves(*args):
    #Get list of objects
    shapeList = pm.ls(pm.listRelatives(c=True))
    groupList = pm.ls(pm.group(em=True, n='Curve#'))
    listAll = []
    for obj in groupList:
        listAll.extend(shapeList)
        listAll.extend(groupList)

    #Parent objects to one Curve
    pm.select(listAll)
    pm.parent(r=True, s=True)

    #Clean scene
    trans = pm.ls(tr=True)
    parents = pm.listRelatives(pm.ls(), type='transform', p=True)
    deleteList=[]
    for obj in trans:
        if obj not in parents:
            deleteList.append(obj)

    #if len(deleteList) > 0:
       #pm.delete(deleteList)
