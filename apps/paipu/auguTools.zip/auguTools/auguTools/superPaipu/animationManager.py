import os, sys
import maya.cmds as cmds
import assetManager
reload(assetManager)

def populateAnimationList(mode):
    cmds.textScrollList( "animationScrollList", edit = True, removeAll = True )
    path = assetManager.getProjectPath().rpartition("/")[0] + "/paipu" + "/" + assetManager.getCategories()[0]
    try:
        folders = os.listdir(path)
        shots = []
        for folder in folders:
            if folder.rpartition(".")[0] == "": # filter non folder type
                shots.append(folder)
        for shot in shots:
            cmds.textScrollList("animationScrollList", edit = True, append = shot)
    except WindowsError:
        cmds.warning("Super Paipu can't read this directory :(")
        cmds.inViewMessage( amg="Super Paipu <hl>can't read</hl> this directory <hl>:(</hl>", pos='botCenter', fade=True )

def onShotSelection(*args):
    cmds.image("thumbnailImage", edit = True, image = superPaipuPath + "/icons/thumbnail.png")

def shotVersion():
    cmds.rowColumnLayout("savePublishLayout", edit = True, visible = True)
    cmds.frameLayout("assetOptionFrame", edit = True, visible = True)
    cmds.rowColumnLayout("savePublishLayout", edit = True, visible = True)
    populateVersions("save")
    populateVersions("publish")
    assetManager.populate_puref_list(assetManager.getProjectPath().rpartition("/")[0] + "/paipu" + "/" + assetManager.getCategories()[0] + '/' + cmds.textScrollList( "animationScrollList", query = True, selectItem = True )[0])




def populateVersions(mode, *args):
    assetManager.getProjectPath()
    if assetManager.getProjectPath()!= "":
        cmds.iconTextButton("saveButton", edit = True, enable = True)
        cmds.iconTextButton("publishButton", edit = True, enable = True)
        imagepath = ""
        category = cmds.optionMenu("categoriesOptionMenu", query = True, value = True)
        if category in ["02_layout", '03_animation']:
            imagepath = assetManager.getProjectPath().rpartition("/")[0] + "/paipu" + "/" + category + "/" + cmds.textScrollList( "animationScrollList", query = True, selectItem = True )[0] + "/thumbnail.png"
            cmds.image("thumbnailImage", edit = True, image = imagepath)
            menuItems = []
            path = ""
            parent = ""
            if mode == "save":
                menuItems = cmds.optionMenu('saveFileVersionsList', q=True, itemListLong=True) # itemListLong returns the children
                path = assetManager.getProjectPath().rpartition("/")[0] + "/paipu" + "/" + cmds.optionMenu("categoriesOptionMenu", query = True, value = True) + "/" + cmds.textScrollList( "animationScrollList", query = True, selectItem = True )[0] + "/01_save"
                parent = "saveFileVersionsList"
            if mode == "publish":
                menuItems = cmds.optionMenu('publishFileVersionsList', q=True, itemListLong=True) # itemListLong returns the children
                path = assetManager.getProjectPath().rpartition("/")[0] + "/paipu" + "/" + cmds.optionMenu("categoriesOptionMenu", query = True, value = True) + "/" + cmds.textScrollList( "animationScrollList", query = True, selectItem = True )[0] + "/02_publish"
                parent = "publishFileVersionsList"
            if menuItems:
                cmds.deleteUI(menuItems)
            try:
                folders = os.listdir(path)
                for version in reversed(folders):
                    if version.rpartition(".")[0] == "": # filter non folder type
                        cmds.menuItem(label = version, parent = parent)
                assetManager.onVersionSelected(mode)
            except WindowsError:
                cmds.warning("Oops, can't refresh version list :(")
                cmds.inViewMessage( amg="Oops, <hl>can't refresh</hl> version list <hl>:(</hl>", pos='botCenter', fade=True )
