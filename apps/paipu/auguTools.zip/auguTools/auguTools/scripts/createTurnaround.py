import maya.cmds as cmds

def create():
	try:
		cmds.inViewMessage( amg='Creating <hl>turn</hl> scene...', pos='botCenter', fade=True )
		cmds.file( cmds.internalVar(usd = True) + "/auguTools/scripts/templates/set_turn.ma", reference = True, force = True, namespace = "LightingScene")
		cmds.file( cmds.internalVar(usd = True) + "/auguTools/scripts/templates/set_turn.ma", importReference = True, force = True )
		# set render settings
		cmds.setAttr("LightingScene:lgt_environment_allShape.tex0", cmds.internalVar(usd = True) + "/auguTools/scripts/templates/artist_workshop_1k.hdr", type='string')
		cmds.setAttr("defaultRenderGlobals.currentRenderer", "redshift", type="string")
		cmds.setAttr("defaultRenderGlobals.imageFormat", 51)
		cmds.setAttr("defaultRenderGlobals.animation", True)
		cmds.setAttr("defaultRenderGlobals.startFrame", 1.0)
		cmds.setAttr("defaultRenderGlobals.endFrame", 200.0)
		cmds.setAttr("defaultResolution.width", 1920)
		cmds.setAttr("defaultResolution.height", 1080)
		# set timeline
		cmds.currentUnit( time = 'film' )
		cmds.currentTime( 0, edit=True )
		cmds.playbackOptions(edit = True, minTime = 0, maxTime = 200, animationStartTime = 0, animationEndTime = 200, playbackSpeed = 1.0)

		cmds.inViewMessage( amg='<hl>Done</hl> !', pos='botCenter', fade=True )
	except:
		cmds.inViewMessage( amg="Oops it didn\'t work, too bad <hl>:(</hl>", pos='botCenter', fade=True )
		cmds.warning( 'Oops it didn\'t work, too bad :(' )
