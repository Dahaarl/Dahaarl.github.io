import maya.cmds as cmds
import os
from shutil import copyfile
from .. import assetManager
reload(assetManager)

#################################################  FONCTIONS  #################################################

try:
    cmds.loadPlugin( 'AbcExport.mll' )
except:
    pass


def selectByType(type=''):
    ''' Filter selection by type of objects. Return the full path of the objects. '''
    selection = cmds.ls(selection=True)
    cmds.select(selection, hierarchy=True)
    new_selection = []
    all_objects = cmds.ls(selection=True)
    print('SELECTING ALL ' + type + 's...')
    for obj in all_objects:
        if cmds.objectType(obj) == type:
            # print(obj + ': ' + cmds.objectType(obj))
            obj = cmds.listRelatives(obj, parent=True, fullPath=True)[0]
            if cmds.getAttr(obj+'.visibility') == True:
                new_selection.append(obj)
                print(obj)
    return new_selection


def build_objects_command(list):
    ''' Build the command string needed by the AbcExport cmd from a given list. '''
    new_list = []
    for index, obj in enumerate(list):
        new_list.append("-root " + str(obj))
    command = ' '.join(new_list)
    return command


def export(grp, grp_to_export, save_path):
    ''' Export alembic file based on the group given calling 'selectByType()' and  'build_objects_command()'. '''
    cmds.select(grp)
    if grp_to_export[grp].get('type') == 'camera':
        geometries = selectByType(type='camera')
    else:
        geometries = selectByType(type='mesh')
    command = build_objects_command(geometries)
    print('ROOT COMMAND: ' + command)
    cmds.select(geometries)
    if grp_to_export[grp].get('type') == 'animation':
        cmds.AbcExport(j="-frameRange " + grp_to_export[grp].get('start') + " " + grp_to_export[grp].get('end') +  " -frameRelativeSample -0.2 -frameRelativeSample 0 -frameRelativeSample 0.2 -attr GuerillaTags -step 1.0 -renderableOnly -uvWrite -writeColorSets -writeFaceSets -worldSpace -writeVisibility -stripNamespaces -dataFormat ogawa " + command + " -file " + save_path + grp_to_export[grp].get('name') + ".abc")
    elif grp_to_export[grp].get('type') == 'camera':
        cmds.AbcExport(j="-frameRange " + grp_to_export[grp].get('start') + " " + grp_to_export[grp].get('end') +  " -attr GuerillaTags -step 1.0 -renderableOnly -uvWrite -writeColorSets -writeFaceSets -worldSpace -writeVisibility -stripNamespaces -dataFormat ogawa " + command + " -file " + save_path + grp_to_export[grp].get('name') + ".abc")
    elif grp_to_export[grp].get('type') == 'static':
        cmds.AbcExport(j="-frameRange " + grp_to_export[grp].get('start') + " " + grp_to_export[grp].get('end') +  " -attr GuerillaTags -step 1.0 -renderableOnly -uvWrite -writeColorSets -writeFaceSets -worldSpace -writeVisibility -stripNamespaces -dataFormat ogawa " + command + " -file " + save_path + grp_to_export[grp].get('name') + ".abc")



#################################################  MACRO  #################################################

def build_abc_export(grp_to_export):
    path = assetManager.getProjectPath().rpartition('/')[0]
    guerilla_path = path + "/paipu/05_guerilla/02_rendu/"
    shot = cmds.file(query = True, sceneName = True).rpartition('/')[2].rpartition('.')[0]
    save_path = guerilla_path + shot + '/alembics/'
    try: os.makedirs(save_path)
    except: pass
    # move template.gproject into shot folder if not not already exists
    print(guerilla_path + shot +  '/' + shot +'.gproject')
    if not os.path.isfile(guerilla_path + shot + '/' + shot +'.gproject'):
        copyfile(assetManager.superPaipuPath + '/toguerilla/template.gproject', guerilla_path + shot + '/' + shot +'.gproject')
        print("------------------------------ Creating " + shot +'.gproject...')
    else:
        print("------------------------------ " + shot +'.gproject already exists, skip creation.')
    for grp in grp_to_export:
        cmds.select(grp)
        print('------------------------------ Exporting ' + grp + ' ...')
        export(grp, grp_to_export, save_path)
        print('------------------------------ Done')
    print('Exportation complete !\n------------------------------')
