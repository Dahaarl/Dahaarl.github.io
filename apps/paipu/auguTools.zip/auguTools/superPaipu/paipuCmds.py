import os, sys
import maya.cmds as cmds
import shutil
import animationManager
reload(animationManager)

superPaipuPath = str(os.path.dirname(os.path.abspath(__file__)))

def create_project(path):
    # Create folder to path
    cmds.inViewMessage( amg='Creating New <hl>Project</hl>', pos='botCenter', fade=True )
    if not cmds.workspace(fullName = True) == path:
        cmds.workspace(path, newWorkspace=True )
    cmds.workspace( path, openWorkspace=True )
    cmds.workspace(fileRule = ['paipu', 'paipu'])
    cmds.workspace( saveWorkspace=True )
    os.mkdir(path + "/paipu")
    path = path
    with open( path + "/project.superpaipu", "w" ) as f:
        f.write( "D:/backups")
    with open( superPaipuPath + "/current_project.superpaipu", 'w') as f:
        f.write( path + "/project.superpaipu")
    # set path to superPaipu current_path
    update_current_path(path, 'folder')
    # create categories
    for dir_categories in ["01_assets", "02_layout", "03_animation", "04_tmp"]:
        os.mkdir(path + "/paipu/" + dir_categories)
    # create sub_categories
    for dir_assets in ["01_character", "02_props", "03_decor", "04_cameras", "05_setdress"]:
        os.mkdir(path + "/paipu/01_assets/" + dir_assets)
    cmds.inViewMessage( amg='Project Created <hl>:D</hl>', pos='botCenter', fade=True )
def open_project(path):
    update_current_path(path, 'file')
    cmds.inViewMessage( amg='Project Opened <hl>:D</hl>', pos='botCenter', fade=True )



def update_current_path(path, filemode):
    cmds.workspace( path.rpartition("/")[0], openWorkspace=True )
    cmds.workspace( saveWorkspace=True )
    filepath = ""
    data = ""
    if filemode == "file":
        filepath = path
    elif filemode == "folder":
        filepath = path + "/" + "project.superpaipu"
    with open( superPaipuPath + "/current_project.superpaipu", "r" ) as f:
        data = f.read()
    if data != []:
        data = filepath
        with open( superPaipuPath + "/current_project.superpaipu", 'w') as f:
            f.writelines( data )



def add_new_asset(path, name):
    if not os.path.isdir(path + "/paipu/" + name):
        os.mkdir(path + "/" + name)
        shutil.copy(os.path.dirname(os.path.abspath(__file__)) + "/icons/thumbnail.png", path + "/" + name)
        for dir_asset in ["01_geo", "02_lookdev","03_rig", "04_cloth", "05_hair"]:
            if not os.path.isdir(path + "/" + name + "/" + dir_asset):
                os.mkdir(path + "/" + name + "/" + dir_asset)
                for dir_publish in ["01_save", "02_publish", "03_tmp"]:
                    if not os.path.isdir(path + "/" + name + "/" + dir_asset + "/" + dir_publish):
                        os.mkdir(path + "/" + name + "/" + dir_asset + "/" + dir_publish)
                        if dir_publish == "01_save":
                            for dir_version in ["0001"]:
                                if not os.path.isdir(path + "/" + name + "/" + dir_asset + "/" + dir_publish + "/" + dir_version):
                                    os.mkdir(path + "/" + name + "/" + dir_asset + "/" + dir_publish + "/" + dir_version)
                                    if dir_publish == "01_save":
                                        cmds.file(rename = path + "/" + name + "/" + dir_asset + "/" + dir_publish + "/" + dir_version + "/" + name + "_" + dir_asset.partition("_")[2] + ".ma")
                                        cmds.file( save = True, type='mayaAscii', force = True, ignoreVersion = True)
                                    if dir_asset  == "02_lookdev":
                                        shutil.copy(cmds.internalVar(usd = True) + "auguTools/scripts/templates/set_turn.ma", path + "/" + name + "/02_lookdev/" + dir_publish + "/" + dir_version + "/" + name + "_" + dir_asset.partition("_")[2] + ".ma")

        for dir_asset in ["00_sculpt", "07_substance","08_tmp", 'refs']:
            if not os.path.isdir(path + "/" + name + "/" + dir_asset):
                os.mkdir(path + "/" + name + "/" + dir_asset)
    cmds.file(path + "/" + name + "/01_geo" + "/01_save/0001/" + name + "_geo.ma", open = True, force = True, ignoreVersion = True)



def add_new_shot(path, name):
    if not os.path.isdir(path + "/" + name):
        os.mkdir(path + "/" + name)
        shutil.copy(os.path.dirname(os.path.abspath(__file__)) + "/icons/thumbnail.png", path + "/" + name)
        for dir_publish in ["01_save", "02_publish"]:
            if not os.path.isdir(path + "/" + name + "/" + dir_publish):
                os.mkdir(path + "/" + name + "/" + dir_publish)
                for dir_version in ["0001"]:
                    if not os.path.isdir(path + "/" + name + "/" + dir_publish + "/" + dir_version):
                        os.mkdir(path + "/" + name + "/" + dir_publish + "/" + dir_version)
                        if dir_publish == "01_save":
                            cmds.file(rename = path + "/" + name + "/" + dir_publish + "/" + dir_version + "/" + name + ".ma")
                            cmds.file( save = True, type='mayaAscii', force = True, ignoreVersion = True)
                            # set timeline
                            cmds.currentUnit( time = 'film' )
                            cmds.currentTime( 100, edit=True )
                            cmds.playbackOptions(edit = True, minTime = 100, maxTime = 200, animationStartTime = 100, animationEndTime = 200, playbackSpeed = 1.0)
                            # set render settings
                            cmds.setAttr("defaultRenderGlobals.currentRenderer", "redshift", type="string")
                            cmds.setAttr("defaultRenderGlobals.imageFormat", 51)
                            cmds.setAttr("defaultRenderGlobals.animation", True)
                            cmds.setAttr("defaultRenderGlobals.startFrame", 100.0)
                            cmds.setAttr("defaultRenderGlobals.endFrame", 200.0)
                            cmds.setAttr("defaultResolution.width", 1920)
                            cmds.setAttr("defaultResolution.height", 1080)
        if not os.path.isdir(path + "/" + name + "/" + 'refs'):
            os.mkdir(path + "/" + name + "/" + 'refs')
        animationManager.populateVersions("save")




def saveFile(path, version):
    path = cmds.file(query = True, sceneName = True).rpartition("/")[0].rpartition("/")[0]
    fileName = cmds.file(query = True, sceneName = True).rpartition("/")[2]
    version = len(os.listdir(path))
    print(path)
    print(fileName)
    print("current version: {}".format(version))
    newVersion = int(version) + 1
    dirVersion = str(newVersion).zfill(4)
    print(newVersion)
    print(dirVersion)
    os.mkdir(path + "/" + dirVersion)
    path = path + "/" + dirVersion + "/" + fileName
    cmds.file(rename = path)
    cmds.file( save = True, type='mayaAscii', force = True, ignoreVersion = True)
    cmds.inViewMessage( amg='Save Version <hl>' + dirVersion + '</hl>', pos='botCenter', fade=True )

def publishFile(path):
    # referencesEditor.import_all()
    saveFilePath = cmds.file(query = True, sceneName = True)
    fileName = cmds.file(query = True, sceneName = True).rpartition("/")[2]
    all_versions = os.listdir(path)    # list all versions' directories
    if "desktop.ini" in all_versions:
        all_versions.remove("desktop.ini")
    print(all_versions)
    dirVersion = ""
    try:
        last_version = all_versions[-1]
        print(last_version)
        newVersion = int(last_version) + 1
        dirVersion = str(newVersion).zfill(4)
        os.mkdir(path + "/" + dirVersion)
        print(path)
        print(fileName)
        print(last_version)
    except:
        os.mkdir(path + "/0001")
        dirVersion = "0001"
    path = path + "/" + dirVersion + "/" + fileName
    cmds.file(rename = path)
    cmds.file( save = True, type='mayaAscii', force = True, ignoreVersion = True)
    cmds.file(saveFilePath, open = True, force= True, ignoreVersion = True)
    cmds.inViewMessage( amg='Publishing <hl>' + dirVersion + '</hl>...', pos='botCenter', fade=True )
    cmds.inViewMessage( amg="File was published <hl>:)</hl> Back to previous <hl>file</hl>...", pos='botCenter', fade=True )



def takeSnapshot(current_asset):
    oldImageFormat = cmds.getAttr("defaultRenderGlobals.imageFormat")
    cmds.setAttr("defaultRenderGlobals.imageFormat", 32)
    if os.path.isfile(current_asset + "/thumbnail.png"):
        os.remove(current_asset + "/thumbnail.png")
    cmds.playblast( filename = current_asset + "/thumbnail", frame=[cmds.currentTime( query=True )], format="image", percent = 100, forceOverwrite = True, showOrnaments = False, viewer=True, widthHeight=(300,150))
    files = os.listdir(current_asset)
    for f in files:
        if f.rpartition(".")[2] == "png":
            os.rename(current_asset + "/" + f, current_asset + "/thumbnail.png")
    cmds.setAttr("defaultRenderGlobals.imageFormat", oldImageFormat)
