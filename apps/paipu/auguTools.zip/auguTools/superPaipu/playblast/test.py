import subprocess
import os
paipu_path = str(os.path.dirname(os.path.abspath(__file__)))

path = 'D:/AUGU/COURS/ANIM/Acting/maya/paipu/03_animation/cesar_funeral/01_save/0021/playblasts/'
video = path + 'cesar_funeral.mov'
cmd = paipu_path + "\\ffmpeg\\ffmpeg -y -i " + video + " -vf \"drawtext=fontfile=C:/Windows/Fonts/arial.ttf:fontsize=30:text=%{n}:fontcolor=white:x=50:y=h-50:box=1:boxcolor=black:boxborderw=10\" -codec:a copy -pix_fmt yuv420p output.mov"
print(cmd)
subprocess.call(cmd, shell=True)

#:box=1:boxcolor=black:boxborderw=5
#x=(w-text_w)/2:y=h-60*t:box=1:boxcolorblack@0.5:boxborderw=5
