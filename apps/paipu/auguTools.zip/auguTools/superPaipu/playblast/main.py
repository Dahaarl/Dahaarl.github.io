import maya.cmds as cmds
import os
import shutil
import subprocess

paipu_path = str(os.path.dirname(os.path.abspath(__file__)))

def do_playblast():
    ''' Launch a playblast for the selected viewport. Based on the Render Settings of the Maya scene
        Specs:
            - From Render Settings
            - Quicktime H264 (if available)
            - Quality: 100
            - Scale: 4
    '''
    current_scene, current_scene_path = get_scene_infos()
    try:
        last_version = get_playblast_list()[0]
        new_version = str(int(last_version)+1).zfill(4)
    except:
        new_version = '0001'
    new_version_path = current_scene_path + '/playblasts/' + new_version + '/'
    os.makedirs(new_version_path)
    resolution = [cmds.getAttr('defaultResolution.width'), cmds.getAttr('defaultResolution.height')] # get resolution from render settings
    try:
        sound = cmds.ls(type='audio')[0]
        video = cmds.playblast(filename=new_version_path + current_scene, sound=sound, format='qt', percent=100, forceOverwrite=True, viewer=False, showOrnaments=False, widthHeight=(resolution[0], resolution[1]))
    except:
        video = cmds.playblast(filename=new_version_path + current_scene, format='qt', percent=100, forceOverwrite=True, viewer=False, showOrnaments=False, widthHeight=(resolution[0], resolution[1]))
    cmds.inViewMessage( amg='<hl>PLAYBLAST</hl> done !', pos='botCenter', fade=True )
    if new_version == '0001':
        last_version_path = current_scene_path + '/playblasts/0001/' + current_scene + '.mov'
        shutil.copy(last_version_path, current_scene_path + '/playblasts/' + current_scene + '.mov')
    else:
        reorder_playblasts_list()
    last_playblast_version = get_playblast_list()[0]
    input = current_scene_path + '/playblasts/' + last_playblast_version + '/' + current_scene +'.mov'
    output = current_scene_path + '/playblasts/' + current_scene +'.mov'
    # add_infos_on_shot(input, output)
    print('input: ' + input)
    print('output: ' + output)
    os.startfile(output)


def reorder_playblasts_list():
    ''' Take the last playblast version and replace the master playblast. '''
    current_scene, current_scene_path = get_scene_infos()
    last_version = get_playblast_list()[0]
    last_version_path = current_scene_path + '/playblasts/' + str(last_version) + '/' + current_scene + '.mov'
    shutil.copy(last_version_path, current_scene_path + '/playblasts/' + current_scene + '.mov')


def add_infos_on_shot(input, output):
    # take the video and pass it through ffmpeg to add frame count
    cmd = paipu_path + "\\ffmpeg\\ffmpeg -y -i " + input + " -vf \"drawtext=fontfile=C:/Windows/Fonts/arial.ttf:fontsize=40:text=%{n}:fontcolor=white:x=50:y=h-50:box=1:boxcolor=black@0.5:boxborderw=20\" -codec:a copy -pix_fmt yuv420p " + output
    print(cmd)
    subprocess.call(cmd, shell=True)
    # subprocess.call(cmd, shell=True)


def get_scene_infos():
    ''' Return scene name and its path. '''
    current_scene = cmds.file(query = True, sceneName = True).rpartition('/')[2].rpartition('.')[0]
    current_scene_path = cmds.file(query = True, sceneName = True).rpartition('/')[0]
    return current_scene, current_scene_path


def get_playblast_list():
    ''' Return number of playblast version and the last one. '''
    current_scene_path = get_scene_infos()[1]
    list = os.listdir(current_scene_path + '/playblasts/')
    count = len(list)
    if count > 1:
        del list[-1] # remove master playblast from list
        last_version  = list[-1]
    elif count == 1:
        last_version = 1
    return last_version, list, count
