import os, sys
from datetime import datetime
import maya.cmds as cmds
import animationManager
reload(animationManager)
import paipuCmds
reload(paipuCmds)
import backup.main as backup
reload(backup)
import referencesEditor
reload(referencesEditor)


superPaipuPath = str(os.path.dirname(os.path.abspath(__file__)))


def populateCategoriesMenu():
    populateCurrentAssetPathLabel()
    enableSavePublish()
    menuItems = cmds.optionMenu('categoriesOptionMenu', q=True, itemListLong=True) # itemListLong returns the children
    if menuItems:
        cmds.deleteUI(menuItems)
    cmds.image("thumbnailImage", edit = True, image = superPaipuPath + "/icons/thumbnail.png")
    cmds.frameLayout("assetOptionFrame", edit = True, visible = False)
    if getProjectPath() != "":
        cmds.textScrollList("categoriesScrollList", edit = True, removeAll = True)
        cmds.textScrollList("namesScrollList", edit = True, removeAll = True)
        cmds.textScrollList("typesScrollList", edit = True, removeAll = True)
        try:
            categories = os.listdir( getProjectPath().rpartition("/")[0] + "/paipu")
            for category in categories:
                if category.rpartition(".")[0] == "": # filter non folder type
                    if not category in ["04_tmp", "05_guerilla", "06_houdini", "edits"]: # filter unwanted folder
                        cmds.menuItem(label = category, parent = "categoriesOptionMenu")
        except WindowsError:
            cmds.warning("Can't load the project :( Please re-open it")
            cmds.inViewMessage( amg="Can't load the project <hl>:(</hl> Please re-open it", pos='botCenter', fade=True )


def populateCategoriesList(*args):
    if cmds.optionMenu( "categoriesOptionMenu", query = True, value = True ) in ["02_layout", "03_animation"]:
        cmds.rowColumnLayout( "animationLayout", edit = True, visible = True )
        cmds.rowColumnLayout( "assetLayout", edit = True, visible = False )
        animationManager.populateAnimationList( cmds.optionMenu("categoriesOptionMenu", query = True, value = True).rpartition("_")[2] )
    else:
        cmds.rowColumnLayout( "animationLayout", edit = True, visible = False)
        cmds.rowColumnLayout( "assetLayout", edit = True, visible = True)
    populateCurrentAssetPathLabel()
    enableSavePublish()
    cmds.image("thumbnailImage", edit = True, image = superPaipuPath + "/icons/thumbnail.png")
    if getCategories()[0] in ["02_layout", "03_animation"]:
        cmds.button("newAssetButton", edit = True, enable = True, label = "Create New Shot")
    else:
        cmds.button("newAssetButton", edit = True, enable = False)
    cmds.frameLayout("assetOptionFrame", edit = True, visible = False)
    getProjectPath()
    if getProjectPath()!= "":
        categoriesItems = cmds.textScrollList("categoriesScrollList", query = True, allItems = True)
        cmds.textScrollList("namesScrollList", edit = True, removeAll = True)
        if categoriesItems != None:
            cmds.textScrollList("categoriesScrollList", edit = True, removeAll = True)
        cmds.textScrollList("typesScrollList", edit = True, removeAll = True)
        path = getProjectPath().rpartition("/")[0] + "/paipu" + "/" + getCategories()[0]
        try:
            folders = os.listdir(path)
            categories = []
            for folder in folders:
                if folder.rpartition(".")[0] == "": # filter non folder type
                    categories.append(folder)
            for category in categories:
                cmds.textScrollList("categoriesScrollList", edit = True, append = category)
            categoriesItems = cmds.textScrollList("categoriesScrollList", query = True, allItems = True)
        except WindowsError:
            cmds.warning("Can't load the project :( Please re-open it")
            cmds.inViewMessage( amg="Can't load the project <hl>:(</hl> Please re-open it", pos='botCenter', fade=True )


def populateNamesList(*args):
    populateCurrentAssetPathLabel()
    enableSavePublish()
    cmds.image("thumbnailImage", edit = True, image = superPaipuPath + "/icons/thumbnail.png")
    cmds.button("newAssetButton", edit = True, enable = True, label = "Create Asset")
    cmds.frameLayout("assetOptionFrame", edit = True, visible = False)
    getProjectPath()
    if getProjectPath()!= "":
        namesItems = cmds.textScrollList("namesScrollList", query = True, allItems = True)
        if namesItems != None:
            cmds.textScrollList("namesScrollList", edit = True, removeAll = True)
        cmds.textScrollList("typesScrollList", edit = True, removeAll = True)
        path = getProjectPath().rpartition("/")[0] + "/paipu" + "/" + getCategories()[0] + "/" + getCategories()[1] + "/"
        folders = os.listdir(path)
        categories = []
        for folder in folders:
            if folder.rpartition(".")[0] == "": # filter non folder type
                categories.append(folder)
        for category in categories:
            cmds.textScrollList("namesScrollList", edit = True, append = category)


def populateTypesList(*args):
    populateCurrentAssetPathLabel()
    enableSavePublish()
    cmds.button("newAssetButton", edit = True, enable = False, label = "Create Asset")
    cmds.frameLayout("assetOptionFrame", edit = True, visible = False)
    populateVersions("save")
    populateVersions("publish")
    if not getCategories()[1] in ["01_character", "02_props", "03_envt", "04_setdress"]:
        cmds.image("thumbnailImage", edit = True, image = superPaipuPath + "/icons/thumbnail.png")
    if cmds.optionMenu("categoriesOptionMenu", query = True, value = True) != "":
        imagepath = getProjectPath().rpartition("/")[0] + "/paipu" + "/" + getCategories()[0] + "/" + getCategories()[1] + "/" + getCategories()[2] + getCategories()[3] + "/thumbnail.png"
        cmds.image("thumbnailImage", edit = True, image = imagepath)
    getProjectPath()
    if getProjectPath()!= "":
        namesItems = cmds.textScrollList("namesScrollList", query = True, allItems = True)
        if namesItems != None:
            cmds.textScrollList("typesScrollList", edit = True, removeAll = True)
        path = getProjectPath().rpartition("/")[0] + "/paipu" + "/" + getCategories()[0] + "/" + getCategories()[1] + "/" + getCategories()[2] + "/" + getCategories()[3]
        folders = os.listdir(path)
        categories = []
        for folder in folders:
            if folder.rpartition(".")[0] == "": # filter non folder type
                categories.append(folder)
        for category in categories:
            if category not in ["00_sculpt", "07_substance", "08_tmp", 'refs']:
                cmds.textScrollList("typesScrollList", edit = True, append = category)


def populateVersions(mode, *args):
    getProjectPath()
    if getProjectPath()!= "":
        menuItems = []
        path = ""
        parent = ""
        if mode == "save":
            menuItems = cmds.optionMenu('saveFileVersionsList', q=True, itemListLong=True) # itemListLong returns the children
            path = getProjectPath().rpartition("/")[0] + "/paipu" + "/" + getCategories()[0] + "/" + getCategories()[1] + "/" + getCategories()[2] + "/" + getCategories()[3] + "/01_save/"
            parent = "saveFileVersionsList"
        if mode == "publish":
            menuItems = cmds.optionMenu('publishFileVersionsList', q=True, itemListLong=True) # itemListLong returns the children
            path = getProjectPath().rpartition("/")[0] + "/paipu" + "/" + getCategories()[0] + "/" + getCategories()[1] + "/" + getCategories()[2] + "/" + getCategories()[3] + "/02_publish/"
            parent = "publishFileVersionsList"
        if menuItems:
            cmds.deleteUI(menuItems)
        try:
            folders = os.listdir(path)
            for version in reversed(folders):
                if version.rpartition(".")[0] == "": # filter non folder type
                    cmds.menuItem(label = version, parent = parent)
            onVersionSelected(mode, cmds.optionMenu("categoriesOptionMenu", query = True, value = True))
        except WindowsError:
            pass


def onSelectedAsset(*args):
    populateCurrentAssetPathLabel()
    enableSavePublish()
    cmds.button("newAssetButton", edit = True, enable = False)
    cmds.frameLayout("assetOptionFrame", edit = True, visible = True)
    path = getProjectPath().rpartition("/")[0] + "/paipu" + "/" + getCategories()[0] + "/" + getCategories()[1] + "/" + getCategories()[2] + "/" + getCategories()[3] + "/02_publish/"
    try:
        files = os.listdir(path)
        for version in files:
            if version.rpartition(".")[2] == "ma":
                return
        populateVersions("save")
        populateVersions("publish")
        populate_puref_list(path.rpartition('/')[0].rpartition('/')[0].rpartition('/')[0])
    except WindowsError:
        cmds.warning("Super Paipu can't read this directory :(")
        cmds.inViewMessage( amg="Super Paipu <hl>can't read</hl> this directory <hl>:(</hl>", pos='botCenter', fade=True )


def populate_puref_list(path):
    purefFile = os.listdir(path+'/refs/')
    cmds.textScrollList('purefList', edit = True, removeAll = True)
    for file in purefFile:
        cmds.textScrollList('purefList', edit=True, append=[file])

def open_puref_file(*args):
    file = cmds.textScrollList('purefList', query=True, selectItem=True)[0]
    try:
        path = getProjectPath().rpartition("/")[0] + "/paipu" + "/" + getCategories()[0] + "/" + getCategories()[1] + "/" + getCategories()[2] + '/refs/' + file
        cmds.inViewMessage( amg='Opening <hl>'+file+'</hl>', pos='botCenter', fade=True )
        os.startfile(path)
    except:
        path = getProjectPath().rpartition("/")[0] + "/paipu" + "/" + getCategories()[0] + '/' + cmds.textScrollList( "animationScrollList", query = True, selectItem = True )[0] + '/refs/' + file
        cmds.inViewMessage( amg='Opening <hl>'+file+'</hl>', pos='botCenter', fade=True )
        os.startfile(path)


def onVersionSelected(mode, *args):
    getProjectPath()
    if getProjectPath()!= "":
        category = cmds.optionMenu("categoriesOptionMenu", query = True, value = True)
        filename = ""
        path = ""
        try:
            if category in ["01_assets"]:
                if mode == "save":
                    path = getProjectPath().rpartition("/")[0] + "/paipu/" + getCategories()[0] + "/" + getCategories()[1] + "/" + getCategories()[2] + "/" + getCategories()[3] + "/01_save/" + cmds.optionMenu("saveFileVersionsList", query = True, value = True)
                if mode == "publish":
                    path = getProjectPath().rpartition("/")[0] + "/paipu/" + getCategories()[0] + "/" + getCategories()[1] + "/" + getCategories()[2] + "/" + getCategories()[3] + "/02_publish/" + cmds.optionMenu("publishFileVersionsList", query = True, value = True)
            if category in ["02_layout", "03_animation"]:
                if mode == "save":
                    path = getProjectPath().rpartition("/")[0] + "/paipu/" + category + "/" + cmds.textScrollList( "animationScrollList", query = True, selectItem = True )[0] + "/01_save/" + cmds.optionMenu("saveFileVersionsList", query = True, value = True)
                if mode == "publish":
                    path = getProjectPath().rpartition("/")[0] + "/paipu/" + category + "/" + cmds.textScrollList( "animationScrollList", query = True, selectItem = True )[0] + "/02_publish/" + cmds.optionMenu("publishFileVersionsList", query = True, value = True)
        except TypeError:
                pass
        try:
            files = os.listdir(path)
            for file in files:
                if file.rpartition(".")[0] != "": # filter folder type
                    filename = file
            lastmodified= os.stat(path + "/" + filename).st_mtime
            time = datetime.fromtimestamp(lastmodified)
            if mode == "save":
                cmds.text("saveFileMetadata", edit = True, label = str(time).rpartition(".")[0], width = 140)
                cmds.textField("saveCommentField", edit = True, fileName = "")
                if os.path.isfile(path + "/comment.txt"):
                    with open( path + "/comment.txt", "r" ) as f:
                        content = f.read()
                        cmds.textField("saveCommentField", edit = True, fileName = content)
            if mode == "publish":
                cmds.text("publishFileMetadata", edit = True, label = str(time).rpartition(".")[0], width = 140)
                cmds.textField("publishCommentField", edit = True, fileName = "")
                if os.path.isfile(path + "/comment.txt"):
                    with open( path + "/comment.txt", "r" ) as f:
                        content = f.read()
                        cmds.textField("publishCommentField", edit = True, fileName = content)
        except WindowsError:
            pass


def enableSavePublish():
    currentScene = cmds.file(query = True, sceneName = True)
    path = ""
    # check if current maya scene is an asset from super Paipu's project
    if "01_assets" in currentScene:
        path = cmds.file(query = True, sceneName = True).rpartition("/")[0].rpartition("/")[0].rpartition("/")[0].rpartition("/")[0].rpartition("/")[0].rpartition("/")[0].rpartition("/")[0].rpartition("/")[0] + "/project.superpaipu"
    if "02_layout" in currentScene or "03_animation" in currentScene:
        path = cmds.file(query = True, sceneName = True).rpartition("/")[0].rpartition("/")[0].rpartition("/")[0].rpartition("/")[0].rpartition("/")[0].rpartition("/")[0] + "/project.superpaipu"
    if os.path.isfile(path):
        cmds.iconTextButton("saveButton", edit = True, enable = True)
        cmds.iconTextButton("publishButton", edit = True, enable = True)
        cmds.iconTextButton("snapshotButton", edit = True, enable = True)
    else:
        # cmds.iconTextButton("saveButton", edit = True, enable = False)
        cmds.iconTextButton("publishButton", edit = True, enable = False)
        cmds.iconTextButton("snapshotButton", edit = True, enable = False)


def onNewProjectPressed(*args):
    returnPath = cmds.fileDialog2( fileMode = 3, fileFilter = None, dialogStyle = 2, caption = "Choose a location")[0]
    paipuCmds.create_project(returnPath)
    returnPath = returnPath + "/project.superpaipu"
    paipuCmds.open_project(returnPath)
    populateCategoriesMenu()
    populateCategoriesList()
def onOpenProjectPressed(*args):
    returnPath = cmds.fileDialog2( fileMode = 1, fileFilter = "project.superpaipu", dialogStyle = 2, caption = "Choose a project")[0]
    paipuCmds.open_project(returnPath)
    cmds.textScrollList("categoriesScrollList", edit = True, removeAll = True)
    populateCategoriesMenu()
    populateCategoriesList()



def openSaveFile(mode, *args):
    path = ""
    result = cmds.confirmDialog(
        title='Open Save Version',
        message='Are you sure?',
        button=['Yes','No'],
        defaultButton='Yes',
        cancelButton='No',
        dismissString='No' )
    if result == 'Yes':
        getProjectPath()
        if getProjectPath()!= "":
            category = cmds.optionMenu("categoriesOptionMenu", query = True, value = True)
            if category in ["01_assets"]:
                path = getProjectPath().rpartition("/")[0] + "/paipu" + "/" + getCategories()[0] + "/" + getCategories()[1] + "/" + getCategories()[2] + "/" + getCategories()[3] + "/01_save/" + cmds.optionMenu("saveFileVersionsList", query = True, value = True)
            if category in ["02_layout", "03_animation"]:
                path = getProjectPath().rpartition("/")[0] + "/paipu" + "/" + category + "/" + cmds.textScrollList( "animationScrollList", query = True, selectItem = True )[0] + "/01_save/" + cmds.optionMenu("saveFileVersionsList", query = True, value = True)
            try:
                files = os.listdir(path)
                for file in files:
                    if file.rpartition(".")[2] == "ma":
                        if mode == "classique":
                            cmds.file(path + "/" + file, open = True, force = True, ignoreVersion = True)
                            cmds.inViewMessage( amg="<hl>SAVE</hl> " + cmds.file(query = True, sceneName = True).rpartition("/")[0].rpartition("/")[2] + '<hl>' + " " + cmds.file(query = True, sceneName = True).rpartition("/")[2].rpartition(".")[0] + '</hl> opened', pos='botCenter', fade=True )
                        if mode == "reference":
                            cmds.file(path + "/" + file, reference = True, type='mayaAscii', force = True, ignoreVersion = True, namespace= file.rpartition(".")[0])
                            cmds.inViewMessage( amg="<hl>SAVE</hl> " + path.rpartition("/")[2] + ' <hl>' + getCategories()[2] + "_" + getCategories()[3].rpartition("_")[2].lower() + "</hl> imported", pos='botCenter', fade=True )
                populateCurrentAssetPathLabel()
            except WindowsError:
                cmds.warning("No file to open... :(")
    if cmds.window('references_editor', query = True, exists = True):
        referencesEditor.refresh_ui()
        print 'reload ui'


def openInNewMaya(*args):
    path = ''
    result = cmds.confirmDialog(
        title='Open in a new Maya ?',
        message='Do you want to open this file in a new Maya ?',
        button=['Yes','No'],
        defaultButton='Yes',
        cancelButton='No',
        dismissString='No' )
    if result == 'Yes':
        getProjectPath()
        if getProjectPath()!= "":
            category = cmds.optionMenu("categoriesOptionMenu", query = True, value = True)
            if category in ["01_assets"]:
                path = getProjectPath().rpartition("/")[0] + "/paipu" + "/" + getCategories()[0] + "/" + getCategories()[1] + "/" + getCategories()[2] + "/" + getCategories()[3] + "/01_save/" + cmds.optionMenu("saveFileVersionsList", query = True, value = True) + "/" + getCategories()[2] + "_" + getCategories()[3].rpartition("_")[2].lower() + ".ma"
            if category in ["02_layout", "03_animation"]:
                path = getProjectPath().rpartition("/")[0] + "/paipu" + "/" + category + "/" + cmds.textScrollList( "animationScrollList", query = True, selectItem = True )[0] + "/01_save/" + cmds.optionMenu("saveFileVersionsList", query = True, value = True) + "/" + getCategories()[2] + "_" + getCategories()[3].rpartition("_")[2].lower() + ".ma"
        os.startfile(path)


def openPublishFile(mode, *args):
    path = ""
    result = cmds.confirmDialog(
        title='Open Save Version',
        message='Are you sure?',
        button=['Yes','No'],
        defaultButton='Yes',
        cancelButton='No',
        dismissString='No' )
    if result == 'Yes':
        getProjectPath()
        if getProjectPath()!= "":
            category = cmds.optionMenu("categoriesOptionMenu", query = True, value = True)
            if category in ["01_assets"]:
                path = getProjectPath().rpartition("/")[0] + "/paipu" + "/" + getCategories()[0] + "/" + getCategories()[1] + "/" + getCategories()[2] + "/" + getCategories()[3] + "/02_publish/" + cmds.optionMenu("publishFileVersionsList", query = True, value = True)
            if category in ["02_layout", "03_animation"]:
                path = getProjectPath().rpartition("/")[0] + "/paipu" + "/" + category + "/" + cmds.textScrollList( "animationScrollList", query = True, selectItem = True )[0] + "/02_publish/" + cmds.optionMenu("publishFileVersionsList", query = True, value = True)
            files = os.listdir(path)
            for file in files:
                if file.rpartition(".")[2] == "ma":
                    if mode == "classique":
                        cmds.file(path + "/" + file, open = True, force = True, ignoreVersion = True)
                        cmds.inViewMessage( amg="<hl>PUBLISH</hl> " + cmds.file(query = True, sceneName = True).rpartition("/")[0].rpartition("/")[2] + '<hl>' + " " + cmds.file(query = True, sceneName = True).rpartition("/")[2].rpartition(".")[0] + '</hl> opened', pos='botCenter', fade=True )
                    if mode == "reference":
                        cmds.file(path + "/" + file, reference = True, type='mayaAscii', force = True, ignoreVersion = True, namespace= file.rpartition(".")[0])
                        cmds.inViewMessage( amg="<hl>PUBLISH</hl> " + path.rpartition("/")[2] + ' <hl>' + getCategories()[2] + "_" + getCategories()[3].rpartition("_")[2].lower() + "</hl> imported", pos='botCenter', fade=True )
            populateCurrentAssetPathLabel()

    if cmds.window('references_editor', query = True, exists = True):
        referencesEditor.refresh_ui()
        print 'reload ui'


def populateCurrentAssetPathLabel():
    filename = cmds.file(query = True, sceneName = True).rpartition("/")[2].rpartition(".")[0]
    version = cmds.file(query = True, sceneName = True).rpartition("/")[0].rpartition("/")[0].rpartition("/")[2].rpartition("_")[2]
    version_number = cmds.file(query = True, sceneName = True).rpartition("/")[0].rpartition("/")[2]
    if (version == "") or not ("/paipu/" in cmds.file(query = True, sceneName = True)):
        cmds.text("currentAssetPathLabel", edit = True, label = "no asset")
    else:
        cmds.text("currentAssetPathLabel", edit = True, label = filename + " > " + version + " > " + version_number)


def onSavePressed(*args):
    filePath = cmds.file(query = True, sceneName = True).rpartition("/")[0] # get scene path
    saveDir = filePath.rpartition("/")[0].rpartition("/")[0] + "/01_save" # get save directory
    files = os.listdir(saveDir)     # list all versions' directories
    paipuCmds.saveFile(saveDir, files[-1])
    print(files)
    populateVersions("save")
    populateCurrentAssetPathLabel()
    animationManager.populateVersions("save")
def onPublishPressed(*args):
    filePath = cmds.file(query = True, sceneName = True).rpartition("/")[0]  # get scene path
    saveDir = filePath.rpartition("/")[0].rpartition("/")[0] + "/02_publish" # get save directory
    references = referencesEditor.get_references_list()
    print('references nb: ' + str(len(references) ))
    if len(references) != 0:
        result = cmds.confirmDialog(
            title='Publish this file',
            message="There is some referenced files in this scene. You should import them all !",
            button=['import all and publish','cancel'],
            defaultButton='import all and publish',
            cancelButton='cancel',
            dismissString='cancel' )
        if result == 'import all and publish':
            referencesEditor.import_all(ask=False)
            paipuCmds.publishFile(saveDir)
            populateVersions("publish")
            populateCurrentAssetPathLabel()
            animationManager.populateVersions("publish")
        else:
            cmds.warning("Publish was canceled :(")
    else:
        result = cmds.confirmDialog(
            title='Publish this file',
            message="Do you want to publish ?",
            button=['publish !','cancel'],
            defaultButton='publish !',
            cancelButton='cancel',
            dismissString='cancel' )
        if result == 'publish !':
            referencesEditor.import_all(ask=False)
            paipuCmds.publishFile(saveDir)
            populateVersions("publish")
            populateCurrentAssetPathLabel()
            animationManager.populateVersions("publish")
        else:
            cmds.warning("Publish was canceled :(")
def saveComment(mode, *args):
    category = cmds.optionMenu("categoriesOptionMenu", query = True, value = True)
    if category in ["02_layout", "03_animation"]:
        if mode == "save":
            path = getProjectPath().rpartition("/")[0] + "/paipu" + "/" + cmds.optionMenu("categoriesOptionMenu", query = True, value = True) + "/" + cmds.textScrollList( "animationScrollList", query = True, selectItem = True )[0] + "/01_save/" + cmds.optionMenu("saveFileVersionsList", query = True, value = True)
            if not os.path.isfile(path + "/comment.txt"):
                with open( path + "/comment.txt", "w" ) as f:
                    f.writelines("")
            with open( path + "/" + "comment.txt", "w" ) as f:
                f.writelines(cmds.textField("saveCommentField", query = True, fileName = True))
        if mode == "publish":
            path = getProjectPath().rpartition("/")[0] + "/paipu" + "/" + cmds.optionMenu("categoriesOptionMenu", query = True, value = True) + "/" + cmds.textScrollList( "animationScrollList", query = True, selectItem = True )[0] + "/02_publish/" + cmds.optionMenu("publishFileVersionsList", query = True, value = True)
            if not os.path.isfile(path + "/comment.txt"):
                with open( path + "/comment.txt", "w" ) as f:
                    f.writelines("")
            with open( path + "/" + "comment.txt", "w" ) as f:
                f.writelines(cmds.textField("publishCommentField", query = True, fileName = True))
    if category in ["01_assets"]:
        if mode == "save":
            path = getProjectPath().rpartition("/")[0] + "/paipu" + "/" + getCategories()[0] + "/" + getCategories()[1] + "/" + getCategories()[2] + "/" + getCategories()[3] + "/01_save/" + cmds.optionMenu("saveFileVersionsList", query = True, value = True)
            if not os.path.isfile(path + "/comment.txt"):
                with open( path + "/comment.txt", "w" ) as f:
                    f.writelines("")
            with open( path + "/" + "comment.txt", "w" ) as f:
                f.writelines(cmds.textField("saveCommentField", query = True, fileName = True))
        if mode == "publish":
            path = getProjectPath().rpartition("/")[0] + "/paipu" + "/" + getCategories()[0] + "/" + getCategories()[1] + "/" + getCategories()[2] + "/" + getCategories()[3] + "/02_publish/" + cmds.optionMenu("publishFileVersionsList", query = True, value = True)
            if not os.path.isfile(path + "/comment.txt"):
                with open( path + "/comment.txt", "w" ) as f:
                    f.writelines("")
            with open( path + "/" + "comment.txt", "w" ) as f:
                f.writelines(cmds.textField("publishCommentField", query = True, fileName = True))


def onSnapshotPressed(*args):
    category = cmds.file(query = True, sceneName = True)
    path = ""
    if "01_assets" in category:
        category = category.rpartition("/")[0].rpartition("/")[0].rpartition("/")[0].rpartition("/")[0].rpartition("/")[0].rpartition("/")[0].rpartition("/")[2]
    if ("02_layout" in category) or ("03_animation" in category):
        category = category.rpartition("/")[0].rpartition("/")[0].rpartition("/")[0].rpartition("/")[0].rpartition("/")[2]
    if category in ["01_assets"]:
        path = cmds.file(query = True, sceneName = True).rpartition("/")[0].rpartition("/")[0].rpartition("/")[0].rpartition("/")[0] # get scene path
    if category in ["02_layout", "03_animation"]:
        path = cmds.file(query = True, sceneName = True).rpartition("/")[0].rpartition("/")[0].rpartition("/")[0] # get scene path
    paipuCmds.takeSnapshot(path)
    populateTypesList()


def onNewAssetPressed(*args):
    result = cmds.promptDialog(
            title='Create Asset',
            message='Enter new Name:',
            button=['OK', 'Cancel'],
            defaultButton='OK',
            cancelButton='Cancel',
            dismissString='Cancel')
    if result == 'OK':
        text = cmds.promptDialog(query=True, text=True)
        if text != "":
            cmds.file( force=True, new=True )
            if getCategories()[0] == "01_assets":
                path = getProjectPath().rpartition("/")[0] + "/paipu" + "/" + getCategories()[0] + "/" + getCategories()[1] + getCategories()[2] + "/"
                paipuCmds.add_new_asset(path, text)
            if getCategories()[0] == "02_layout":
                path = getProjectPath().rpartition("/")[0] + "/paipu" + "/" + getCategories()[0] + "/"
                paipuCmds.add_new_shot(path, text)
            if getCategories()[0] == "03_animation":
                path = getProjectPath().rpartition("/")[0] + "/paipu" + "/" + getCategories()[0] + "/"
                paipuCmds.add_new_shot(path, text)
            populateNamesList()
            populateCurrentAssetPathLabel()
        else:
            cmds.warning("No name is set ! :(")



def getProjectPath():
    if os.path.isfile( superPaipuPath + "/current_project.superpaipu"):
        with open( superPaipuPath + "/current_project.superpaipu", "r" ) as f:
            projectPath = f.read()
            return projectPath
    else:
        cmds.warning("No project to read, please open one")
        cmds.inViewMessage( amg='<hl>No project</hl> to read, please open one', pos='botCenter', fade=True )
def getBackupPath():
    if os.path.isfile( getProjectPath()):
        with open( getProjectPath(), "r" ) as f:
            backupPath = f.read()
            return backupPath
    else:
        cmds.warning("No backup destination set, please set one")
        cmds.inViewMessage( amg='No <hl>backup destination</hl> set :(', pos='botCenter', fade=True )



def onSetBackupDestinationPressed(*args):
    returnPath = cmds.fileDialog2( fileMode = 3, fileFilter = None, dialogStyle = 2, caption = "Choose a location")[0]
    paipuBackup.setBackupDestination(getProjectPath(), returnPath)
def onSaveBackupPressed(*args):
    backup.backup_thread( getProjectPath().rpartition("/")[0], getBackupPath() )



def openInExplorer(what,*args):
    path = ""
    if what == "project":
        path = getProjectPath().rpartition("/")[0] + "/paipu" + "/"
        if path == "":
            cmds.inViewMessage( amg='No <hl>project</hl> set <hl>:(</hl>', pos='botCenter', fade=True )
            return
    elif what == "backup":
        path = getBackupPath()
        if path == "":
            cmds.inViewMessage( amg='No <hl>backup destination</hl> set <hl>:(</hl>', pos='botCenter', fade=True )
            return
    elif what == "paipuNetwork":
        path = "W:/E3/TRAVAIL/scripts/auguTools/"
        if not os.path.isdir(path):
            cmds.inViewMessage( amg='Can\'t reach <hl>network</hl> :(', pos='botCenter', fade=True )
    elif what == "paipuLocal":
        path = cmds.internalVar(userScriptDir = True)
    elif what == "category":
        path = getProjectPath().rpartition("/")[0] + "/paipu" + "/" + getCategories()[0] + "/" + getCategories()[1] + "/"
    elif what == "type":
        path = getProjectPath().rpartition("/")[0] + "/paipu" + "/" + getCategories()[0] + "/" + getCategories()[1] + "/" + getCategories()[2] + "/"
    try:
        os.startfile(path)
    except WindowsError:
        pass


def getCategories(*args):
    tmp_currentMainCategory = cmds.optionMenu("categoriesOptionMenu", query = True, value = True)
    tmp_currentCategory = cmds.textScrollList("categoriesScrollList", query = True, selectItem = True)
    tmp_currentNameCategory = cmds.textScrollList("namesScrollList", query = True, selectItem = True)
    tmp_currentTypesCategory = cmds.textScrollList("typesScrollList", query = True, selectItem = True)
    if tmp_currentMainCategory != None:
        currentMainCategory = tmp_currentMainCategory
    else:
        currentMainCategory = ""
    if tmp_currentCategory != None:
        currentCategory = tmp_currentCategory[0]
    else:
        currentCategory = ""
    if tmp_currentNameCategory != None:
        currentNameCategory = tmp_currentNameCategory[0]
    else:
        currentNameCategory = ""
    if tmp_currentTypesCategory != None:
        currentTypesCategory = tmp_currentTypesCategory[0]
    else:
        currentTypesCategory = ""
    return [currentMainCategory, currentCategory, currentNameCategory, currentTypesCategory]
