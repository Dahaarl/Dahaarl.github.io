import maya.cmds as cmds
import pymel.core as pm
import os
from functools import partial

superPaipuPath = str(os.path.dirname(os.path.abspath(__file__)))
global_visibility = 'open'

def init():
    if cmds.window('references_editor', query = True, exists = True):
        cmds.deleteUI('references_editor')


def refresh_ui():
    build_references_ui()


def add(ref):
    cmds.file(ref, reference=True)
    refresh_ui()
    return ref


def add_ui(*args):
    extension = "*.ma"
    ref = cmds.fileDialog2(fileFilter=extension, dialogStyle=2, fileMode=1)[0]
    cmds.file(ref, reference=True)
    refresh_ui()
    return ref


def replace(ref):
    extension = "*.ma"
    new_ref = cmds.fileDialog2(fileFilter=extension, caption='Replace reference', okCaption='replace', dialogStyle=2, fileMode=1)[0]
    remove(ref)
    add(new_ref)
    refresh_ui()
    return new_ref


def import_ref(ref):
    ref_path = cmds.referenceQuery(ref, filename = True)
    cmds.file(ref_path, importReference=True, defaultNamespace=True)
    pm.namespace(removeNamespace = ref.replace('RN', ''), mergeNamespaceWithRoot = True)
    refresh_ui()


def update(ref):
    status = get_reference_status(ref)
    if status == 'last':
        return
    ref_path = cmds.referenceQuery(ref, filename = True)
    filename = ref_path.rpartition('/')[2]
    save_dir = ref_path.rpartition('/')[0].rpartition('/')[0]
    version_list = []
    for element in os.listdir(save_dir):
        if element.rpartition('.')[0] == '':
            version_list.append(element)
            print element
    new_ref = save_dir + '/' + version_list[-1] + '/' + filename
    cmds.file(new_ref, loadReference=ref )
    print(cmds.referenceQuery(ref, filename = True) + ' was updated')
    refresh_ui()
    return new_ref


def toggle_visibility(ref):
    if cmds.referenceQuery(ref, isLoaded=True):
        cmds.file(unloadReference=ref)
    else:
        cmds.file(loadReference=ref)
    refresh_ui()


# def toggle_all_visibility():
#     global global_visibility
#     refs_list = get_references_list()
#     print(refs_list)
#     for ref in refs_list:
#         if global_visibility == 'open':
#             cmds.file(unloadReference=ref)
#             global_visibility = 'close'
#             continue
#         # elif global_visibility == 'close':
#         #     cmds.file(loadReference=ref)
#         #     global_visibility = 'open'
#         #     continue
#         print global_visibility
#     refresh_ui()


def remove(ref, ask=False):
    if ask:
        result = cmds.confirmDialog(
            title='Remove reference',
            message='Do you want to remove '+ref+' ?',
            button=['Yes','No'],
            defaultButton='Yes',
            cancelButton='No',
            dismissString='No' )
        if result == 'Yes':
            ref_path = cmds.referenceQuery(ref, filename = True)
            cmds.file(ref_path, removeReference=True)
            refresh_ui()
    else:
        ref_path = cmds.referenceQuery(ref, filename = True)
        cmds.file(ref_path, removeReference=True)
        refresh_ui()


def remove_all():
    result = cmds.confirmDialog(
        title='Remove reference',
        message='Do you want to remove all the referenced files ?',
        button=['Yes','No'],
        defaultButton='Yes',
        cancelButton='No',
        dismissString='No' )
    if result == 'Yes':
        refs_list = get_references_list()
        for ref in refs_list:
            remove(ref)


def update_all():
    result = cmds.confirmDialog(
        title='Remove reference',
        message='Do you want to update all the referenced files ?',
        button=['Yes','No'],
        defaultButton='Yes',
        cancelButton='No',
        dismissString='No' )
    if result == 'Yes':
        refs_list = get_references_list()
        for ref in refs_list:
           update(ref)

def import_all(ask=True):
    if ask:
        result = cmds.confirmDialog(
            title='Remove reference',
            message='Do you want to import all the referenced files ?',
            button=['Yes','No'],
            defaultButton='Yes',
            cancelButton='No',
            dismissString='No' )
        if result == 'Yes':
            refs_list = get_references_list()
            for ref in refs_list:
               import_ref(ref)
    else:
        refs_list = get_references_list()
        for ref in refs_list:
           import_ref(ref)


def get_references_list():
    return cmds.ls(references=True)


def build_references_ui(*args):
    global global_visibility
    if cmds.window('references_editor', query = True, exists = True):
        cmds.deleteUI('references_editor')
    window = cmds.window('references_editor', title='References Editor', iconName='Short Name')
    window = cmds.window('references_editor', edit=True, width = 500, height = 400, maximizeButton = False, resizeToFitChildren = False, sizeable = False)

    mainColumn = cmds.columnLayout('mainLayoutReferenceEditor', adjustableColumn = True, width = 210 )
    cmds.separator(height= 10, style = 'none')

    # top bar
    cmds.rowColumnLayout(numberOfRows=1, columnSpacing=(1, 4), width=298)
    cmds.separator(width=2)
    cmds.iconTextButton(image1=superPaipuPath + '/icons/' + 'add.svg', statusBarMessage='Add references', annotation='Add references', command=add_ui)
    cmds.text(label='  Referenced Files :', font='boldLabelFont', align='left', width=305)
    cmds.text(label='apply to all :  ')
    # cmds.iconTextButton(image1=superPaipuPath + '/icons/' + 'visibility_' + global_visibility + '.svg', statusBarMessage='Toggle visibility', annotation='Toggle visibility', command=toggle_all_visibility)
    cmds.iconTextButton(image1=superPaipuPath + '/icons/' + 'update.svg', statusBarMessage='Update references', annotation='Update references', command=update_all)
    cmds.iconTextButton(image1=superPaipuPath + '/icons/' + 'import.svg', statusBarMessage='Import reference', annotation='Import reference', command=import_all)
    cmds.iconTextButton(image1=superPaipuPath + '/icons/' + 'remove.svg', statusBarMessage='Remove references', annotation='Remove references', command=remove_all)

    cmds.setParent(mainColumn)
    cmds.separator(height= 8)

    # referenced files list here
    references_list = get_references_list()
    for ref in references_list:
        try:
            path = cmds.referenceQuery(ref, filename = True)
            version = path.rpartition('/')[0].rpartition('/')[2]
            add_reference_ui(ref, version)
        except:
            pass
    cmds.showWindow( 'references_editor' )


def add_reference_ui(ref, version):
    status = get_reference_status(ref)
    visibility = get_visibility(ref)
    # reference row widget
    cmds.setParent('mainLayoutReferenceEditor')
    cmds.rowColumnLayout(numberOfRows=1, columnSpacing=(1, 4), width=298)
    cmds.separator(width= 20, style='none')
    cmds.iconTextButton(image1=superPaipuPath + '/icons/' + status + '_version.svg', statusBarMessage='status' + ' version', annotation='Reference status')
    cmds.text(label=ref.replace('RN',''), width=216)
    cmds.text(label='|', width=2)
    cmds.text(label=version, width=50)
    cmds.text(label='|', width=2)
    cmds.separator(width= 15, style = 'none')
    cmds.iconTextButton(image1=superPaipuPath + '/icons/' + 'visibility_' + visibility + '.svg', statusBarMessage='Toggle visibility', annotation='Toggle visibility', command=partial(toggle_visibility, ref))
    cmds.iconTextButton(image1=superPaipuPath + '/icons/' + 'update.svg', statusBarMessage='Update reference', annotation='Update reference', command=partial(update, ref))
    cmds.iconTextButton(image1=superPaipuPath + '/icons/' + 'replace.svg', statusBarMessage='Replace reference', annotation='Replace reference', command=partial(replace, ref))
    cmds.iconTextButton(image1=superPaipuPath + '/icons/' + 'import.svg', statusBarMessage='Import reference', annotation='Import reference', command=partial(import_ref, ref))
    cmds.iconTextButton(image1=superPaipuPath + '/icons/' + 'remove.svg', statusBarMessage='Remove reference', annotation='Remove reference', command=partial(remove, ref, True))
    cmds.setParent('mainLayoutReferenceEditor')


def get_reference_status(ref):
    path = cmds.referenceQuery(ref, filename = True)
    version = path.rpartition('/')[0].rpartition('/')[2]
    dir_path = path.rpartition('/')[0].rpartition('/')[0]
    dir_list = []
    for element in os.listdir(dir_path):
        if element.rpartition('.')[0] == '':
            dir_list.append(element)
    if str(dir_list[-1]) == str(version):
        status = 'last'
    else:
        status = 'not_last'
    return status


def get_visibility(ref):
    if cmds.referenceQuery(ref, isLoaded=True):
        visibility = 'open'
    else:
        visibility = 'close'
    return visibility


#### ROADMAP UI
# Popup warning quand publish si il reste des references
#    - import all
#    - publish anyway
# Import references
# Add reference
