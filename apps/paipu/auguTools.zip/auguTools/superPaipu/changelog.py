import maya.cmds as cmds
import os


superPaipuPath = str(os.path.dirname(os.path.abspath(__file__)))


def check_use():
    utilisation = ''
    with open(superPaipuPath + '/changelog/log.txt', 'r') as f:
        utilisation = f.read()
    if int(utilisation) == 0:
        build_changelog_ui()

    with open(superPaipuPath + '/changelog/log.txt', 'w') as f:
        f.write(str(int(utilisation)+1))
    print(utilisation)
    print(str(int(utilisation)+1))


def get_changelog():
    changelog = ''
    with open(superPaipuPath + '/changelog/changelog.txt', 'r') as f:
        changelog = f.read()
    return changelog


def build_changelog_ui():
    if cmds.window('changelog_ui', query = True, exists = True):
        cmds.deleteUI('changelog_ui')
    window = cmds.window('changelog_ui', title='Changelog', iconName='Short Name')
    window = cmds.window('changelog_ui', edit=True, width = 250, height = 125, maximizeButton = False, resizeToFitChildren = True, sizeable = False)
    mainColumn = cmds.columnLayout('mainLayoutChangelog', adjustableColumn = True, width = 400 )
    cmds.separator(height= 10, style = 'none')
    changelog = get_changelog()
    cmds.text(label=changelog, align='left')
    cmds.showWindow(window)
