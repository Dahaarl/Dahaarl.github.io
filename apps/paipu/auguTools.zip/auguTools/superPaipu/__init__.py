import os, sys
import maya.cmds as cmds

superPaipuPath = str(os.path.dirname(os.path.abspath(__file__)))

def check_version():
    current_version = ""
    network_version = ""
    with open( superPaipuPath + "/version.superpaipu", 'r') as f:
        current_version = f.read()

    with open( "W:/E3/TRAVAIL/scripts/auguTools/scripts/auguTools/superPaipu/version.superpaipu", 'r') as f:
        network_version = f.read()

    cmds.inViewMessage( amg='Checking for <hl>updates</hl>...', pos='botCenter', fade=True )
    print(current_version + "=" + network_version)
    if current_version != network_version:
        cmds.inViewMessage( amg='New version of <hl>Paipu</hl> found !', pos='botCenter', fade=True )
        print("no")
        result = cmds.confirmDialog(
            title='New Version !',
            message="There's a new version of Paipu !",
            button=['Go to new version','Don\'t care'],
            defaultButton='Go to new version',
            cancelButton='Don\'t care',
            dismissString='Don\'t care' )
        if result == 'Go to new version':
            os.startfile(cmds.internalVar(userScriptDir = True))
            os.startfile("W:/E3/TRAVAIL/scripts/auguTools/scripts/")
    else:
        cmds.inViewMessage( amg='You\'ve got the latest version of <hl>Paipu</hl> !', pos='botCenter', fade=True )

try:
    check_version()
except:
    cmds.inViewMessage( amg="Can\'t reach network to check <hl>Paipu</hl> updates :(", pos='botCenter', fade=True )
    cmds.warning("Can't reach network to check updates :(")
