import maya.cmds as cmds
import shutil
import datetime
import os
import subprocess
import threading


superPaipuPath = str(os.path.dirname(os.path.abspath(__file__)))


def backup_thread(projectPath, destination):
    backup_thread = threading.Thread( target=saveBackup, args=(projectPath, destination) )
    cmds.inViewMessage( amg='Patient you should be while backup is saving... And Maya you\'ll <hl>don\'t close</hl> par contre', pos='botCenter', fade=True )
    print("Patient you should be while backup is saving... And Maya you'll don't close par contre"),
    backup_thread.start()


def setBackupDestination(projectPath, path):
    with open( projectPath, 'w') as f:
        f.write( path )
    cmds.inViewMessage( amg='Backup destination set <hl>:D</hl>', pos='botCenter', fade=True )


def saveBackup(projectPath, destination):
    try:
        backupName = str(datetime.datetime.now().strftime("%Y-%m-%d_%H.%M.%S")) + "_" + "backup"
        shutil.copytree(projectPath + "/paipu", destination + "/" + backupName + "/paipu")
        shutil.copy(projectPath + "/project.superpaipu", destination + "/" + backupName)
        shutil.copy(projectPath + "/workspace.mel", destination + "/" + backupName)
        cmds.inViewMessage( amg='Backup saved <hl>:D</hl>', pos='botCenter', fade=True )
        os.startfile(destination)
    except:
        cmds.warning("Oops something went wrong, check your destination path ! :(")
