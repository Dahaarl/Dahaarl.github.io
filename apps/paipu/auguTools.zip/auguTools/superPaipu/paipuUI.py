import os, sys
from datetime import datetime
import maya.cmds as cmds
from functools import partial
import assetManager
reload(assetManager)
import animationManager
reload(animationManager)
import referencesEditor
reload(referencesEditor)
import changelog.main as changelog
reload(changelog)

superPaipuPath = str(os.path.dirname(os.path.abspath(__file__)))

def create_ui(*args):
    # Main layout
    scrollLayout = cmds.scrollLayout('scrollLayout', childResizable=True, horizontalScrollBarThickness=0, verticalScrollBarThickness=16, width=150, height=675)
    mainLayout = cmds.columnLayout(width=150, height=675)

    # add banner image
    imagePath = superPaipuPath + "/icons/logo.png"
    cmds.image(width = 300, image = imagePath)

    # Menu bar
    headerLayout = cmds.formLayout( parent = mainLayout, height = 27 , width=300)
    menuBar = cmds.menuBarLayout( parent = headerLayout, width=300, height=20)

    # File menu
    cmds.menu(label='File', parent = menuBar)
    cmds.menuItem(label='New project', command = assetManager.onNewProjectPressed)
    cmds.menuItem(label='Open project', command = assetManager.onOpenProjectPressed)
    cmds.menuItem( divider=True, label=" Current project" )
    cmds.menuItem(label="Open in explorer", command = partial(assetManager.openInExplorer, "project"))
    # Backup menu
    cmds.menu(label='Backup', parent = menuBar)
    cmds.menuItem(label='Set backup destination', command = assetManager.onSetBackupDestinationPressed)
    cmds.menuItem(label='Open backup in explorer', command = partial(assetManager.openInExplorer, "backup"))
    cmds.menuItem(label='Save backup', command = assetManager.onSaveBackupPressed)
    # Help menu
    current_version = ""
    with open( superPaipuPath + "/version.superpaipu", 'r') as f:
        current_version = f.read()
    cmds.menu(label='Infos', parent = menuBar)
    cmds.menuItem(label='Open Paipu Folder', command = partial(assetManager.openInExplorer, "paipuLocal"))
    cmds.menuItem(label='Open Paipu Folder on Network\n', command = partial(assetManager.openInExplorer, "paipuNetwork"))
    cmds.menuItem( label=' version ' + current_version + 'ultra test', enable=False)

    cmds.setParent(mainLayout)

    # add categories menu
    assetLayout = cmds.rowLayout(numberOfColumns = 3, height = 30, columnWidth3=(25, 50, 50), columnAlign = [(1, 'left'),(2, 'center'),(3, 'right')])
    categoriesOptionMenu = cmds.optionMenu("categoriesOptionMenu", width=100, height = 25, highlightColor = (0.38, 0.81, 0.39), cc = assetManager.populateCategoriesList)

    cmds.setParent(mainLayout)
    cmds.separator( height = 4)
    cmds.rowColumnLayout( numberOfRows = 1, columnSpacing = (1, 4), width = 298)
    cmds.text(label = " SCENE :", font = "boldLabelFont")
    cmds.text("currentAssetPathLabel", label = "No asset", align='left', width=191)
    cmds.button(label = "refs", width=50, statusBarMessage = "Open references editor", annotation = "Open references editor", command=referencesEditor.build_references_ui)

    cmds.setParent(mainLayout)

    cmds.separator( height = 7)


   ############  ASSET MANAGER LAYOUT  ############


    categoriesLayout = cmds.rowColumnLayout( "assetLayout", numberOfRows = 1, visible = True)
    cmds.textScrollList("categoriesScrollList", highlightColor = (0.38, 0.81, 0.39), height = 100, width = 98, allowMultiSelection = False, selectCommand = assetManager.populateNamesList, doubleClickCommand = partial(assetManager.openInExplorer, "category"))
    cmds.textScrollList("namesScrollList", highlightColor = (0.38, 0.81, 0.39), height = 100, width = 99, allowMultiSelection = False, selectCommand = assetManager.populateTypesList, doubleClickCommand = partial(assetManager.openInExplorer, "type"))
    cmds.textScrollList("typesScrollList", highlightColor = (0.38, 0.81, 0.39), height = 100, width = 98, allowMultiSelection = False, selectCommand = assetManager.onSelectedAsset, doubleClickCommand = partial(assetManager.openSaveFile, "classique"))

    cmds.setParent(mainLayout)



    ############  ANIMATION MANAGER LAYOUT  ############


    categoriesLayout = cmds.rowColumnLayout( "animationLayout", numberOfRows = 1, visible = False)
    cmds.textScrollList("animationScrollList", highlightColor = (0.38, 0.81, 0.39), height = 85, width = 295, allowMultiSelection = False, selectCommand = animationManager.shotVersion, doubleClickCommand = partial(assetManager.openSaveFile, "classique"))

    cmds.setParent(mainLayout)
    cmds.separator( height = 10)

    # add create asset button
    cmds.rowColumnLayout( numberOfRows = 1, columnSpacing = (1, 4), width = 298)
    cmds.button("newAssetButton", label = "Create Asset", width = 240, height = 40, enable = False, statusBarMessage = "Create a new asset", annotation = "Create a new asset", command = assetManager.onNewAssetPressed)

    cmds.iconTextButton("snapshotButton", style='iconAndTextCentered', label = "", flat= False, image1= superPaipuPath + "/icons/snapshot.svg", width = 50, height = 30, enable = False, statusBarMessage = "Take Snapshot", annotation = "Take Snapshot", command = assetManager.onSnapshotPressed)

    # cmds.button("renameAssetButton", label = "Rename Asset", width = 145, height = 40, enable = False, command = assetManager.onRenameAssetPressed)
    # cmds.button("deleteAssetButton", label = "Delete Asset", width = 95, height = 40, enable = False, command = assetManager.onDeleteAssetPressed)
    cmds.setParent(mainLayout)
    cmds.separator(height = 10)

    # add thumbnail
    cmds.image("thumbnailImage", image = superPaipuPath + "icons/thumbnail.png", width=296, height = 150, backgroundColor = (0.2, 0.2, 0.2), enableBackground = True, visible = True)



    ## ASSET FRAME
    cmds.separator(height = 7)
    assetOptionFrame = cmds.frameLayout("assetOptionFrame", label='Asset', width = 295, collapse = False, collapsable = True, visible = False )

    # Add Tab Layout
    form = cmds.formLayout(width = 300)
    tabs = cmds.tabLayout(innerMarginWidth=5, innerMarginHeight=5, width = 300)
    cmds.formLayout( form, edit=True, attachForm=((tabs, 'top', 0), (tabs, 'left', 0), (tabs, 'bottom', 0), (tabs, 'right', 0)) )

    ## SAVE TAB
    child1 = cmds.columnLayout(width = 300)
    cmds.separator(height = 7, style = 'none')
    # save file version
    cmds.rowColumnLayout( numberOfRows = 1, columnSpacing = (1, 4), width = 300)
    fileVersions = cmds.optionMenu("saveFileVersionsList", highlightColor = (0.38, 0.81, 0.39), width = 60, height = 30, cc = partial(assetManager.onVersionSelected, "save" ))
    cmds.text("saveFileMetadata", label = "", width = 140)
    cmds.iconTextButton("saveVersionOpenButton", style='iconOnly', image1= superPaipuPath + "/icons/open_file.svg", flat = False, height = 30, width = 30, statusBarMessage = "Open File", annotation = "Open File", command = partial(assetManager.openSaveFile, "classique") )
    cmds.iconTextButton("saveVersionOpenAsRefButton", style='iconOnly', image1= superPaipuPath + "/icons/open_ref.svg", flat = False, height = 30, width = 30, statusBarMessage = "Open File As Ref", annotation = "Open File As Ref", command = partial(assetManager.openSaveFile, "reference") )
    cmds.setParent("..")
    cmds.separator(height = 3, style = 'none')
	## COMMENT SECTION
    cmds.textField("saveCommentField", font = "obliqueLabelFont", height = 40, width = 300, changeCommand = partial(assetManager.saveComment, "save"), enterCommand = partial(assetManager.saveComment, "save"))
    cmds.setParent( tabs )


    ## PUBLISH TAB
    child2 = cmds.columnLayout(width = 300)
    cmds.separator( height = 7, style = 'none')
    # publish file version
    cmds.rowColumnLayout( numberOfRows = 1, columnSpacing = (1, 4), width = 300)
    fileVersions = cmds.optionMenu("publishFileVersionsList", highlightColor = (0.38, 0.81, 0.39), width = 60, height = 30, cc = partial(assetManager.onVersionSelected, "publish", "01_assets"))
    cmds.text("publishFileMetadata", label = "", width = 140)
    cmds.iconTextButton("publishVersionOpenButton", style='iconOnly', image1= superPaipuPath + "/icons/open_file.svg", flat = False,  height = 30, width = 30, statusBarMessage = "Open File", annotation = "Open File", command = partial(assetManager.openPublishFile, "classique")  )
    cmds.iconTextButton("publishVersionOpenAsRefButton", style='iconOnly', image1= superPaipuPath + "/icons/open_ref.svg", flat = False,  height = 30, width = 30, statusBarMessage = "Open File As Ref", annotation = "Open File As Ref", command = partial(assetManager.openPublishFile, "reference"))
    cmds.setParent("..")
    cmds.separator(height = 3, style = 'none')
	## COMMENT SECTION
    cmds.textField("publishCommentField", font = "obliqueLabelFont", height = 40, width = 300, changeCommand = partial(assetManager.saveComment, "publish"), enterCommand = partial( assetManager.saveComment, "publish"))
    cmds.setParent( tabs )


    ## PUREF TAB
    child3 = cmds.columnLayout(width = 300)
    cmds.separator( height = 7, style = 'none')
    cmds.textScrollList('purefList', highlightColor = (0.38, 0.81, 0.39), height = 80, width = 290, allowMultiSelection = False, doubleClickCommand = assetManager.open_puref_file)
    cmds.setParent("..")
    cmds.setParent("..")
    cmds.setParent( tabs )

    ## TAB LAYOUT
    cmds.tabLayout( tabs, edit=True, tabLabel=((child1, 'Save version'), (child2, 'Publish version'), (child3, 'Puref')) )
    cmds.setParent(mainLayout)
    cmds.separator( height = 7)


    ## SAVE & PUBLISH BUTTONS
    cmds.rowColumnLayout("savePublishLayout", numberOfRows = 1, columnSpacing = (1, 5), visible = True )
    cmds.iconTextButton("saveButton", style='iconAndTextHorizontal', label = "Save version", font = "boldLabelFont", flat= False, image1= superPaipuPath + "/icons/save.svg", marginWidth = 25, align = "left", width = 145, height = 40, enable = False, statusBarMessage = "Save version", annotation = "Save version", command = assetManager.onSavePressed)
    cmds.iconTextButton("publishButton", style='iconAndTextHorizontal', label="Publish", font = "boldLabelFont", flat= False, image1= superPaipuPath + "/icons/publish.svg", flipX = True,  marginWidth = 38, align = "left", width = 145, height = 40, enable = False, statusBarMessage = "Publish", annotation = "Publish", command = assetManager.onPublishPressed)

    cmds.separator( height = 10)

    cmds.setParent(mainLayout)
    if os.path.isfile( superPaipuPath + "/current_project.superpaipu"):
        if os.path.isdir(assetManager.getProjectPath().rpartition("/")[0]):
            assetManager.getProjectPath()
            assetManager.populateCategoriesMenu()
            assetManager.populateCategoriesList()
            # assetManager.enableSavePublish()
        else:
            cmds.warning("No project to open :(")
            cmds.inViewMessage( amg='<hl>No project</hl> to open <hl>:(</hl>', pos='botCenter', fade=True )


def show_ui(*args):
    if cmds.workspaceControl('paipuWorkspace', exists= True):
        cmds.deleteUI('paipuWorkspace')
    cmds.workspaceControl('paipuWorkspace', label='super Paipu', floating = False, height=675, resizeHeight=675, initialHeight=675, initialWidth=300, resizeWidth=300, minimumWidth=300, restore=1, tabToControl=('Outliner', 0) )
    create_ui()
    assetManager.populateCurrentAssetPathLabel()

show_ui()
referencesEditor.init()
changelog.check_use()
