import maya.cmds as cmds
import pymel.core as pm
import os
import subprocess
from functools import partial
import paipuUI
reload(paipuUI)
import assetManager
reload(assetManager)



def toSubstance():
    fileName = cmds.file(query = True, sceneName = True).rpartition("/")[2]
    path = ""
    udim = ""
    format = ""
    project = ""
    if assetManager.getProjectPath() != "":
        path = assetManager.getProjectPath().rpartition("/")[0] + "/01_assets"
    else:
        if not os.path.isdir("C:/tmp/"):
            os.mkdir("C:/tmp/")
            path = "C:/tmp/"
    if cmds.window("substanceWindow", exists = True):
        cmds.deleteUI("substanceWindow")
    window = cmds.window("substanceWindow", title = "Export to Substance", maximizeButton = False, minimizeButton = False, sizeable = False, resizeToFitChildren = False, width = 300, height = 200 )
    substanceUI()
    cmds.showWindow( window )
    cmds.window("substanceWindow", edit = True, width = 300, height = 205 )



def substanceUI():
    mainLayout = cmds.rowColumnLayout( numberOfColumns = 1 )
    cmds.separator(height = 5, style = 'none')

    projectLayout = cmds.rowColumnLayout (numberOfColumns = 5, width = 300, columnWidth = [(1, 2), (2, 92), (3, 170), (4, 30), (5, 5)] )
    cmds.separator(style = 'none')
    cmds.optionMenu("project", width = 80, changeCommand = resetPathLabel)
    cmds.menuItem( label='new project' )
    cmds.menuItem( label='edit project' )
    cmds.setParent(projectLayout)
    cmds.text( "pathLabel", label = "no path")
    cmds.symbolButton( image='folder-open.png', command = setPath)
    cmds.separator(style = 'none')

    cmds.setParent(mainLayout)
    cmds.separator(height = 20, style = 'none')

    firstLayout = cmds.rowColumnLayout (numberOfColumns = 3, width = 300, columnWidth = [(1, 50), (2, 200), (3, 50)] )

    cmds.separator(height = 20, style = 'none')

    cmds.optionMenu("meshformat", label='mesh format: ', width = 100 )
    cmds.menuItem( label='.fbx' )
    cmds.menuItem( label='.obj' )

    cmds.separator(height = 20, style = 'none')
    cmds.separator(height = 20, style = 'none')

    cmds.setParent(firstLayout)

    udimCheckbox = cmds.checkBox("udimCheckbox", label='Create a texture set per UDIM tile')

    cmds.setParent( mainLayout )
    cmds.separator(height = 20, style = 'none')

    cmds.text( label = "Choose a suffix (don\'t change mesh density):")

    cmds.separator(height = 5, style = 'none')

    secondLayout = cmds.rowColumnLayout (numberOfColumns = 3, width = 300, columnWidth = [(1, 2), (2, 298), (3, 2)] )

    cmds.rowColumnLayout(numberOfColumns = 4, width = 298, columnWidth = [(1, 55), (2, 100), (3, 75), (4, 100)])
    cmds.separator(height = 5, style = 'none')
    cmds.textField( "nameLabel", text = "super_name_here")
    cmds.optionMenu("meshSuffix", width = 75 )
    cmds.menuItem( label='_low')
    cmds.menuItem( label='_high')
    cmds.menuItem( label='none')
    cmds.separator(height = 5, style = 'none')

    cmds.setParent(mainLayout)
    cmds.separator(height = 10, style = 'none')
    cmds.button( label = "Export !", height = 40, command = export )


def resetPathLabel(*args):
    cmds.text( "pathLabel", edit = True, label = "no path")

def setPath(project, *args):
    project = cmds.optionMenu("project", query = True, value = True )
    path = ""
    if project == "new project":
        path = cmds.fileDialog2( fileMode = 3, fileFilter = None, dialogStyle = 2, caption = "Choose a location")[0]
        cmds.text( "pathLabel", edit = True, label = path)
    if project == "edit project":
        path = cmds.fileDialog2( fileMode = 1, fileFilter = "*.spp", dialogStyle = 2, caption = "Choose a project")[0]
    cmds.text( "pathLabel", edit = True, label = path)



def export(*args):
    fileName = cmds.textField( "nameLabel", query = True, text = True )
    udim = " "
    project = cmds.optionMenu("project", query = True, value = True )
    path = cmds.text( "pathLabel", query = True, label = True )
    project_path = path
    suffix = cmds.optionMenu( "meshformat", query = True, value = True )

    if path == "no path" or fileName == "":
        cmds.warning("No destination path set !  :'(")
        return

    if suffix == "none":
        suffix = ""
    if  project == "new project":
        path = path + "/" + fileName + suffix
    if project == "edit project":
        path = project_path.rpartition("/")[0] + "/" + fileName + suffix

    if cmds.checkBox("udimCheckbox", query = True, value = True):
        udim = " --split-by-udim"

    if suffix == ".fbx":
        if not cmds.pluginInfo("fbxmaya", query = True, loaded = True):
            pm.loadPlugin("fbxmaya")
        pm.mel.FBXExport(f = path)
    if suffix == ".obj":
        cmds.file(path, save = False, force = True, exportSelected = True, type = "OBJexport")
    if cmds.optionMenu("project", query = True, value = True ) == "new project":
        subprocess.call("start \"substance\" \"C:\Program Files\Allegorithmic\Substance Painter\substance painter.exe\" --mesh " + path + udim, shell = True)
    if cmds.optionMenu("project", query = True, value = True ) == "edit project":
        subprocess.call("start \"substance\" \"C:\Program Files\Allegorithmic\Substance Painter\substance painter.exe\" --mesh " + path + udim + " " + project_path, shell = True)
